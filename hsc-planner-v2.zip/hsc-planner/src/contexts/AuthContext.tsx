import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth, googleProvider, isConfigured } from '@/lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isConfigured && auth) {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setUser(user);
        setLoading(false);
      });
      return unsubscribe;
    } else {
      // Demo mode: Simulate logged in user
      const demoUser = {
        uid: 'demo-user',
        displayName: 'Demo Student',
        email: 'student@hsc26.com',
        photoURL: null,
      } as unknown as User;
      
      setUser(demoUser);
      setLoading(false);
    }
  }, []);

  const signInWithGoogle = async () => {
    if (isConfigured && auth && googleProvider) {
      try {
        await signInWithPopup(auth, googleProvider);
      } catch (error) {
        console.error("Auth error", error);
      }
    } else {
      console.log("Demo login");
    }
  };

  const logout = async () => {
    if (isConfigured && auth) {
      await signOut(auth);
    } else {
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
