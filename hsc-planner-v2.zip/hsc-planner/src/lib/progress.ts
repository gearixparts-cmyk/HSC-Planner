import { SUBJECT_RESOURCES, Subject } from '@/data/subjectResources';

export interface SubjectProgressData {
  id: string;
  name: string;
  totalResources: number;
  completedResources: number;
  percentage: number;
}

export function getSubjectProgress(): SubjectProgressData[] {
  const completedIds = JSON.parse(localStorage.getItem('completed-resources') || '[]');
  
  return SUBJECT_RESOURCES.map((subject: Subject) => {
    let total = 0;
    let completed = 0;

    subject.papers.forEach(paper => {
      Object.values(paper.resources).forEach(resourceList => {
        if (resourceList) {
          resourceList.forEach(resource => {
            total++;
            if (completedIds.includes(resource.id)) {
              completed++;
            }
          });
        }
      });
    });

    return {
      id: subject.id,
      name: subject.name,
      totalResources: total,
      completedResources: completed,
      percentage: total > 0 ? Math.round((completed / total) * 100) : 0
    };
  });
}

export function getOverallProgress(): number {
  const progressData = getSubjectProgress();
  const total = progressData.reduce((acc, curr) => acc + curr.totalResources, 0);
  const completed = progressData.reduce((acc, curr) => acc + curr.completedResources, 0);
  return total > 0 ? Math.round((completed / total) * 100) : 0;
}
