import { differenceInDays, parseISO } from 'date-fns';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: (stats: UserStats) => boolean;
}

export interface UserStats {
  taskStreak: number;
  pomodoroStreak: number;
  totalTasks: number;
  totalPomodoro: number;
  subjectProgress: number;
}

export const BADGES: Badge[] = [
  {
    id: 'streak-3',
    name: '3-Day Streak',
    description: 'Complete at least one task for 3 consecutive days.',
    icon: '🔥',
    condition: (stats) => stats.taskStreak >= 3
  },
  {
    id: 'streak-7',
    name: 'Week Warrior',
    description: 'Complete at least one task for 7 consecutive days.',
    icon: '⚔️',
    condition: (stats) => stats.taskStreak >= 7
  },
  {
    id: 'streak-30',
    name: 'Consistency King',
    description: 'Complete at least one task for 30 consecutive days.',
    icon: '👑',
    condition: (stats) => stats.taskStreak >= 30
  },
  {
    id: 'pomodoro-100',
    name: 'Pomodoro Master',
    description: 'Complete 100 Pomodoro sessions.',
    icon: '🧠',
    condition: (stats) => stats.totalPomodoro >= 100
  },
  {
    id: 'tasks-50',
    name: 'Task Crusher',
    description: 'Complete 50 tasks.',
    icon: '✅',
    condition: (stats) => stats.totalTasks >= 50
  },
  {
    id: 'tasks-500',
    name: 'Productivity Beast',
    description: 'Complete 500 tasks.',
    icon: '💪',
    condition: (stats) => stats.totalTasks >= 500
  }
];

export function calculateStreak(type: 'tasks' | 'pomodoro'): number {
  let streak = 0;
  const today = new Date();
  
  // Check today
  const todayKey = `${type}-${today.toISOString().split('T')[0]}`;
  const hasActivityToday = hasActivity(type, todayKey);
  
  if (hasActivityToday) streak++;

  // Check previous days
  for (let i = 1; i < 365; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const key = `${type}-${date.toISOString().split('T')[0]}`;
    
    if (hasActivity(type, key)) {
      streak++;
    } else {
      // If today has no activity, we allow the streak to continue from yesterday
      // But if yesterday is also missing, streak breaks.
      // Wait, standard streak logic:
      // If today is active, streak = 1 + yesterday streak.
      // If today is NOT active, streak = yesterday streak (if yesterday was active).
      // Actually, usually "Current Streak" implies consecutive days ending today or yesterday.
      
      // Let's refine:
      // Find the most recent active day.
      // If it's today or yesterday, count backwards.
      // If most recent active day is before yesterday, streak is 0.
      break; 
    }
  }
  
  // Re-calculate properly
  let currentStreak = 0;
  let checkDate = new Date();
  
  // Check today
  let key = `${type}-${checkDate.toISOString().split('T')[0]}`;
  if (hasActivity(type, key)) {
    currentStreak++;
  } else {
    // If not today, check yesterday. If yesterday is active, streak starts there.
    // If neither, streak is 0.
    checkDate.setDate(checkDate.getDate() - 1);
    key = `${type}-${checkDate.toISOString().split('T')[0]}`;
    if (!hasActivity(type, key)) {
      return 0;
    }
    // If yesterday is active, we start counting from yesterday (which is now checkDate)
    // But we need to reset checkDate to today to start the loop correctly or just handle the offset.
  }

  // Loop backwards from yesterday (or day before if we started with yesterday)
  // Let's simplify: Iterate backwards from Today.
  // If Today is active, streak++. Then check Yesterday.
  // If Today is NOT active, check Yesterday. If Yesterday active, streak++. Then check day before.
  // If Yesterday NOT active, streak = 0.
  
  streak = 0;
  const d = new Date();
  const k1 = `${type}-${d.toISOString().split('T')[0]}`;
  
  if (hasActivity(type, k1)) {
    streak++;
  }
  
  // Check past days
  let gapFound = false;
  // If today was active, we check yesterday.
  // If today was NOT active, we check yesterday. If active, streak=1. If not, streak=0.
  
  // Actually, simpler loop:
  // Check yesterday. If active, streak++. Check day before...
  // If today is active, add 1 to that result.
  
  let pastStreak = 0;
  for (let i = 1; i < 365; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const key = `${type}-${date.toISOString().split('T')[0]}`;
    if (hasActivity(type, key)) {
      pastStreak++;
    } else {
      break;
    }
  }
  
  if (hasActivity(type, k1)) {
    return pastStreak + 1;
  } else if (pastStreak > 0) {
    return pastStreak;
  }
  
  return 0;
}

function hasActivity(type: 'tasks' | 'pomodoro', key: string): boolean {
  const data = localStorage.getItem(key);
  if (!data) return false;
  
  if (type === 'pomodoro') {
    return parseInt(data) > 0;
  } else {
    const tasks = JSON.parse(data);
    return Array.isArray(tasks) && tasks.some((t: any) => t.completed);
  }
}

export function getUnlockedBadges(): string[] {
  const unlocked = localStorage.getItem('unlocked_badges');
  return unlocked ? JSON.parse(unlocked) : [];
}

export function checkBadges() {
  const taskStreak = calculateStreak('tasks');
  const pomodoroStreak = calculateStreak('pomodoro');
  
  // Calculate totals
  let totalTasks = 0;
  let totalPomodoro = 0;
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key?.startsWith('tasks-')) {
      const tasks = JSON.parse(localStorage.getItem(key) || '[]');
      totalTasks += tasks.filter((t: any) => t.completed).length;
    } else if (key?.startsWith('pomodoro-')) {
      totalPomodoro += parseInt(localStorage.getItem(key) || '0');
    }
  }
  
  const stats: UserStats = {
    taskStreak,
    pomodoroStreak,
    totalTasks,
    totalPomodoro,
    subjectProgress: 0 // TODO: Fetch real progress if needed
  };
  
  const currentUnlocked = getUnlockedBadges();
  const newUnlocked = [...currentUnlocked];
  let changed = false;
  
  BADGES.forEach(badge => {
    if (!currentUnlocked.includes(badge.id) && badge.condition(stats)) {
      newUnlocked.push(badge.id);
      changed = true;
      // Dispatch event or toast could happen here, but better to return new badges
    }
  });
  
  if (changed) {
    localStorage.setItem('unlocked_badges', JSON.stringify(newUnlocked));
    window.dispatchEvent(new Event('badges_updated'));
    return newUnlocked.filter(id => !currentUnlocked.includes(id)); // Return newly unlocked IDs
  }
  
  return [];
}
