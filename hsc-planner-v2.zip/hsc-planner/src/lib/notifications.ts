import { toast } from 'sonner';

export const NOTIFICATION_KEY = 'hsc_notifications_enabled';
export const REMINDER_TIME_KEY = 'hsc_reminder_time';

export function requestNotificationPermission() {
  if (!('Notification' in window)) {
    toast.error("This browser does not support desktop notifications");
    return;
  }

  Notification.requestPermission().then((permission) => {
    if (permission === 'granted') {
      localStorage.setItem(NOTIFICATION_KEY, 'true');
      toast.success("Notifications enabled!");
      // Send a test notification
      new Notification("HSC Planner", {
        body: "Notifications are set up correctly! We'll remind you to study.",
        icon: '/pwa-192x192.png' // Assuming this exists or will exist
      });
    } else {
      localStorage.setItem(NOTIFICATION_KEY, 'false');
      toast.error("Notifications denied");
    }
  });
}

export function checkReminders() {
  const enabled = localStorage.getItem(NOTIFICATION_KEY) === 'true';
  if (!enabled) return;

  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  
  // Daily Study Reminder
  const reminderTime = localStorage.getItem(REMINDER_TIME_KEY) || '19:00'; // Default 7 PM
  const [remHour, remMinute] = reminderTime.split(':').map(Number);

  // Check if it's exactly the reminder time (within the minute)
  // To avoid duplicate notifications, we can store "last_notification_date"
  const lastNotifDate = localStorage.getItem('last_notification_date');
  const today = now.toISOString().split('T')[0];

  if (lastNotifDate !== today && currentHour === remHour && currentMinute === remMinute) {
    new Notification("Time to Study! 📚", {
      body: "Open HSC Planner and complete today's tasks.",
      icon: '/pwa-192x192.png'
    });
    localStorage.setItem('last_notification_date', today);
  }

  // Pomodoro Reminder (e.g., at 10 AM if no sessions done)
  // Only check once a day
  const lastPomoRem = localStorage.getItem('last_pomo_reminder_date');
  if (lastPomoRem !== today && currentHour === 10) {
    const sessions = parseInt(localStorage.getItem(`pomodoro-${today}`) || '0');
    if (sessions === 0) {
      new Notification("Focus Time! 🍅", {
        body: "No focus sessions yet today. Start a Pomodoro now!",
        icon: '/pwa-192x192.png'
      });
      localStorage.setItem('last_pomo_reminder_date', today);
    }
  }
}

// Initialize notification checker
export function initNotifications() {
  if (typeof window === 'undefined') return;
  
  // Check every minute
  return setInterval(checkReminders, 60000);
}
