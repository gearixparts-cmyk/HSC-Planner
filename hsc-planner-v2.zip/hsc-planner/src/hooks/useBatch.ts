import { useState, useEffect } from 'react';

export const BATCH_KEY = 'hsc_batch_year';

export function useBatch() {
  const [batchYear, setBatchYear] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem(BATCH_KEY);
    if (saved) {
      setBatchYear(parseInt(saved));
    }
    setLoading(false);
  }, []);

  const setBatch = (year: number) => {
    localStorage.setItem(BATCH_KEY, year.toString());
    setBatchYear(year);
    // Trigger storage event for other components
    window.dispatchEvent(new Event('storage'));
  };

  return { batchYear, setBatch, loading };
}
