import { useState, useEffect } from 'react';
import { BADGES, checkBadges, getUnlockedBadges, calculateStreak } from '@/lib/gamification';

export function useGamification() {
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);
  const [taskStreak, setTaskStreak] = useState(0);
  const [pomodoroStreak, setPomodoroStreak] = useState(0);

  useEffect(() => {
    const update = () => {
      setUnlockedBadges(getUnlockedBadges());
      setTaskStreak(calculateStreak('tasks'));
      setPomodoroStreak(calculateStreak('pomodoro'));
    };

    update();
    
    window.addEventListener('badges_updated', update);
    window.addEventListener('storage', update);
    
    return () => {
      window.removeEventListener('badges_updated', update);
      window.removeEventListener('storage', update);
    };
  }, []);

  return { unlockedBadges, taskStreak, pomodoroStreak, badges: BADGES };
}
