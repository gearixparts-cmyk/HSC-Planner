import { useState, useEffect } from 'react';
import { checkBadges } from '@/lib/gamification';

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  date: string; // YYYY-MM-DD
}

export function useTasks(date: string) {
  const [tasks, setTasks] = useState<Task[]>([]);

  // Load tasks when date changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`tasks-${date}`);
      setTasks(saved ? JSON.parse(saved) : []);
    } catch (e) {
      console.error("Failed to parse tasks from localStorage", e);
      setTasks([]);
    }
  }, [date]);

  // Save tasks when they change
  useEffect(() => {
    // Avoid saving empty array on initial load if it hasn't been loaded yet
    // But since we load in the first effect, we need to be careful.
    // Actually, simply saving whenever tasks change is fine, AS LONG AS we don't overwrite
    // immediately after date change before load.
    // The issue is that setTasks is async.
    
    // Better approach: Only save if we have loaded for this date?
    // Or just rely on the fact that the first effect runs first.
    // However, if we switch date, 'tasks' is still the old date's tasks until the first effect runs.
    // So the second effect might run with old tasks and new date!
    
    // To fix this, we should NOT use a separate effect for saving if possible, 
    // OR ensure we don't save during the transition.
    
    // But a simpler way for this hook:
    // Don't use a separate save effect. Save inside addTask/toggleTask/deleteTask.
    // This avoids the race condition of effects.
  }, []); 

  const saveTasks = (newTasks: Task[]) => {
    try {
      localStorage.setItem(`tasks-${date}`, JSON.stringify(newTasks));
    } catch (e) {
      console.error("Failed to save tasks to localStorage", e);
    }
  };

  const addTask = (text: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      text,
      completed: false,
      date,
    };
    const newTasks = [...tasks, newTask];
    setTasks(newTasks);
    saveTasks(newTasks);
  };

  const toggleTask = (id: string) => {
    const newTasks = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(newTasks);
    saveTasks(newTasks);
    
    // Check for badges if task is completed
    const task = newTasks.find(t => t.id === id);
    if (task?.completed) {
      checkBadges();
    }
  };

  const deleteTask = (id: string) => {
    const newTasks = tasks.filter(t => t.id !== id);
    setTasks(newTasks);
    saveTasks(newTasks);
  };

  return { tasks, addTask, toggleTask, deleteTask };
}
