import { useState, useEffect } from 'react';

export function useCompletedResources() {
  const [completedResources, setCompletedResources] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('completed-resources');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem('completed-resources');
        setCompletedResources(saved ? JSON.parse(saved) : []);
      } catch {
        setCompletedResources([]);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    // Also listen for custom event for same-window updates
    window.addEventListener('local-storage-update', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('local-storage-update', handleStorageChange);
    };
  }, []);

  const toggleResource = (id: string) => {
    const current = [...completedResources];
    const index = current.indexOf(id);
    
    let newResources;
    if (index >= 0) {
      newResources = current.filter(r => r !== id);
    } else {
      newResources = [...current, id];
    }
    
    setCompletedResources(newResources);
    localStorage.setItem('completed-resources', JSON.stringify(newResources));
    
    // Dispatch custom event to notify other hooks in the same window
    window.dispatchEvent(new Event('local-storage-update'));
    window.dispatchEvent(new Event('storage'));
  };

  return { completedResources, toggleResource };
}
