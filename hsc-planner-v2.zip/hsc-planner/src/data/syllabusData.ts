// ✅ Complete HSC Syllabus Data — All subjects, all chapters with checkboxes

export interface SyllabusChapter {
  id: string;
  bn: string;   // Bengali name
  en: string;   // English name
}

export interface SyllabusPaper {
  paper: string;
  chapters: SyllabusChapter[];
}

export interface SubjectSyllabus {
  subjectId: string;
  name: string;
  papers: SyllabusPaper[];
}

export const SYLLABUS_DATA: SubjectSyllabus[] = [
  {
    subjectId: 'math',
    name: 'উচ্চতর গণিত',
    papers: [
      {
        paper: '1st Paper',
        chapters: [
          { id: 'math-1-1', bn: 'ম্যাট্রিক্স ও নির্ণায়ক', en: 'Matrices and Determinants' },
          { id: 'math-1-2', bn: 'ভেক্টর', en: 'Vectors' },
          { id: 'math-1-3', bn: 'সরলরেখা', en: 'Straight Lines' },
          { id: 'math-1-4', bn: 'বৃত্ত', en: 'Circle' },
          { id: 'math-1-5', bn: 'বিন্যাস ও সমাবেশ', en: 'Permutation and Combination' },
          { id: 'math-1-6', bn: 'ত্রিকোণমিতিক অনুপাত', en: 'Trigonometric Ratios' },
          { id: 'math-1-7', bn: 'সংযুক্ত কোণের ত্রিকোণমিতিক অনুপাত', en: 'Trigonometric Ratios of Associated Angles' },
          { id: 'math-1-8', bn: 'ফাংশন ও ফাংশনের লেখচিত্র', en: 'Functions and Graphs' },
          { id: 'math-1-9', bn: 'অন্তরীকরণ', en: 'Differentiation' },
          { id: 'math-1-10', bn: 'যোগজীকরণ', en: 'Integration' },
        ]
      },
      {
        paper: '2nd Paper',
        chapters: [
          { id: 'math-2-1', bn: 'বাস্তব সংখ্যা ও অসমতা', en: 'Real Numbers and Inequalities' },
          { id: 'math-2-2', bn: 'যোগাশ্রয়ী প্রোগ্রাম', en: 'Linear Programming' },
          { id: 'math-2-3', bn: 'জটিল সংখ্যা', en: 'Complex Numbers' },
          { id: 'math-2-4', bn: 'বহুপদী ও বহুপদী সমীকরণ', en: 'Polynomials and Polynomial Equations' },
          { id: 'math-2-5', bn: 'দ্বিপদী বিস্তৃতি', en: 'Binomial Expansion' },
          { id: 'math-2-6', bn: 'কণিক', en: 'Conics' },
          { id: 'math-2-7', bn: 'বিপরীত ত্রিকোণমিতিক ফাংশন ও সমীকরণ', en: 'Inverse Trig Functions and Equations' },
          { id: 'math-2-8', bn: 'স্থিতিবিদ্যা', en: 'Statics' },
          { id: 'math-2-9', bn: 'গতিবিদ্যা', en: 'Dynamics' },
          { id: 'math-2-10', bn: 'বিস্তার পরিমাপ ও সম্ভাবনা', en: 'Measures of Dispersion and Probability' },
        ]
      }
    ]
  },
  {
    subjectId: 'physics',
    name: 'পদার্থবিজ্ঞান',
    papers: [
      {
        paper: '1st Paper',
        chapters: [
          { id: 'phy-1-1', bn: 'ভৌত জগৎ ও পরিমাপ', en: 'Physical World and Measurement' },
          { id: 'phy-1-2', bn: 'ভেক্টর', en: 'Vectors' },
          { id: 'phy-1-3', bn: 'গতিবিদ্যা', en: 'Kinematics' },
          { id: 'phy-1-4', bn: 'নিউটনীয় বলবিদ্যা', en: 'Newtonian Mechanics' },
          { id: 'phy-1-5', bn: 'কাজ, শক্তি ও ক্ষমতা', en: 'Work, Energy and Power' },
          { id: 'phy-1-6', bn: 'মহাকর্ষ ও অভিকর্ষ', en: 'Gravitation' },
          { id: 'phy-1-7', bn: 'পদার্থের গাঠনিক ধর্ম', en: 'Properties of Matter' },
          { id: 'phy-1-8', bn: 'পর্যাবৃত্ত গতি', en: 'Periodic Motion' },
          { id: 'phy-1-9', bn: 'তরঙ্গ', en: 'Waves' },
          { id: 'phy-1-10', bn: 'আদর্শ গ্যাস ও গ্যাসের গতিতত্ত্ব', en: 'Ideal Gas and Kinetic Theory' },
        ]
      },
      {
        paper: '2nd Paper',
        chapters: [
          { id: 'phy-2-1', bn: 'তাপগতিবিদ্যা', en: 'Thermodynamics' },
          { id: 'phy-2-2', bn: 'স্থির তড়িৎ', en: 'Electrostatics' },
          { id: 'phy-2-3', bn: 'চল তড়িৎ', en: 'Current Electricity' },
          { id: 'phy-2-4', bn: 'তড়িৎ প্রবাহের চৌম্বক ক্রিয়া ও চুম্বকত্ব', en: 'Magnetism' },
          { id: 'phy-2-5', bn: 'তাড়িতচৌম্বক আবেশ ও পরিবর্তী প্রবাহ', en: 'Electromagnetic Induction' },
          { id: 'phy-2-6', bn: 'জ্যামিতিক আলোকবিজ্ঞান', en: 'Geometric Optics' },
          { id: 'phy-2-7', bn: 'ভৌত আলোকবিজ্ঞান', en: 'Physical Optics' },
          { id: 'phy-2-8', bn: 'আধুনিক পদার্থবিজ্ঞানের সূচনা', en: 'Modern Physics' },
          { id: 'phy-2-9', bn: 'পরমাণুর মডেল ও নিউক্লীয় পদার্থবিজ্ঞান', en: 'Atomic Model and Nuclear Physics' },
          { id: 'phy-2-10', bn: 'সেমিকন্ডাক্টর ও ইলেকট্রনিক্স', en: 'Semiconductor and Electronics' },
          { id: 'phy-2-11', bn: 'জ্যোতির্বিজ্ঞান', en: 'Astronomy' },
        ]
      }
    ]
  },
  {
    subjectId: 'chemistry',
    name: 'রসায়ন',
    papers: [
      {
        paper: '1st Paper',
        chapters: [
          { id: 'chem-1-1', bn: 'ল্যাবরেটরির নিরাপদ ব্যবহার', en: 'Laboratory Safety' },
          { id: 'chem-1-2', bn: 'গুণগত রসায়ন', en: 'Qualitative Chemistry' },
          { id: 'chem-1-3', bn: 'মৌলের পর্যায়বৃত্ত ধর্ম ও রাসায়নিক বন্ধন', en: 'Periodic Properties and Chemical Bonding' },
          { id: 'chem-1-4', bn: 'রাসায়নিক পরিবর্তন', en: 'Chemical Changes' },
          { id: 'chem-1-5', bn: 'কর্মমুখী রসায়ন', en: 'Applied Chemistry' },
        ]
      },
      {
        paper: '2nd Paper',
        chapters: [
          { id: 'chem-2-1', bn: 'পরিবেশ রসায়ন', en: 'Environmental Chemistry' },
          { id: 'chem-2-2', bn: 'জৈব রসায়ন', en: 'Organic Chemistry' },
          { id: 'chem-2-3', bn: 'পরিমাণগত রসায়ন', en: 'Quantitative Chemistry' },
          { id: 'chem-2-4', bn: 'তড়িৎ রসায়ন', en: 'Electrochemistry' },
          { id: 'chem-2-5', bn: 'অর্থনৈতিক রসায়ন', en: 'Economic Chemistry' },
        ]
      }
    ]
  },
  {
    subjectId: 'biology',
    name: 'জীববিজ্ঞান',
    papers: [
      {
        paper: '1st Paper (উদ্ভিদবিজ্ঞান)',
        chapters: [
          { id: 'bio-1-1', bn: 'কোষ ও এর গঠন', en: 'Cell and its Structure' },
          { id: 'bio-1-2', bn: 'কোষ বিভাজন', en: 'Cell Division' },
          { id: 'bio-1-3', bn: 'কোষ রসায়ন', en: 'Cell Chemistry' },
          { id: 'bio-1-4', bn: 'অণুজীব', en: 'Microorganisms' },
          { id: 'bio-1-5', bn: 'শৈবাল ও ছত্রাক', en: 'Algae and Fungi' },
          { id: 'bio-1-6', bn: 'ব্রায়োফাইটা ও টেরিডোফাইটা', en: 'Bryophyta and Pteridophyta' },
          { id: 'bio-1-7', bn: 'নগ্নবীজী ও আবৃতবীজী উদ্ভিদ', en: 'Gymnosperms and Angiosperms' },
          { id: 'bio-1-8', bn: 'টিস্যু ও টিস্যুতন্ত্র', en: 'Tissue and Tissue System' },
          { id: 'bio-1-9', bn: 'উদ্ভিদ শারীরতত্ত্ব', en: 'Plant Physiology' },
          { id: 'bio-1-10', bn: 'উদ্ভিদ প্রজনন', en: 'Plant Reproduction' },
          { id: 'bio-1-11', bn: 'জীবপ্রযুক্তি', en: 'Biotechnology' },
          { id: 'bio-1-12', bn: 'জীবের পরিবেশ, বিস্তার ও সংরক্ষণ', en: 'Ecology and Conservation' },
        ]
      },
      {
        paper: '2nd Paper (প্রাণিবিজ্ঞান)',
        chapters: [
          { id: 'bio-2-1', bn: 'প্রাণির বিভিন্নতা ও শ্রেণিবিন্যাস', en: 'Animal Diversity and Classification' },
          { id: 'bio-2-2', bn: 'প্রাণির পরিচিতি (হাইড্রা, ঘাসফড়িং, রুই মাছ)', en: 'Animal Introduction' },
          { id: 'bio-2-3', bn: 'পরিপাক ও শোষণ', en: 'Digestion and Absorption' },
          { id: 'bio-2-4', bn: 'রক্ত ও সংবহন', en: 'Blood and Circulation' },
          { id: 'bio-2-5', bn: 'শ্বাসক্রিয়া ও শ্বসন', en: 'Respiration' },
          { id: 'bio-2-6', bn: 'বর্জন ও রেচন', en: 'Excretion' },
          { id: 'bio-2-7', bn: 'চলন ও অঙ্গচালনা', en: 'Movement and Locomotion' },
          { id: 'bio-2-8', bn: 'সমন্বয় ও নিয়ন্ত্রণ', en: 'Coordination and Control' },
          { id: 'bio-2-9', bn: 'প্রাণির প্রজনন', en: 'Animal Reproduction' },
          { id: 'bio-2-10', bn: 'মানবদেহের প্রতিরক্ষা', en: 'Human Body Defence' },
          { id: 'bio-2-11', bn: 'জিনতত্ত্ব ও বিবর্তন', en: 'Genetics and Evolution' },
          { id: 'bio-2-12', bn: 'প্রাণির আচরণ', en: 'Animal Behaviour' },
        ]
      }
    ]
  },
  {
    subjectId: 'ict',
    name: 'তথ্য ও যোগাযোগ প্রযুক্তি',
    papers: [
      {
        paper: 'All Chapters',
        chapters: [
          { id: 'ict-1', bn: 'তথ্য ও যোগাযোগ প্রযুক্তি: বিশ্ব ও বাংলাদেশ প্রেক্ষিত', en: 'ICT: Global and Bangladesh Context' },
          { id: 'ict-2', bn: 'কমিউনিকেশন সিস্টেমস ও নেটওয়ার্কিং', en: 'Communication Systems and Networking' },
          { id: 'ict-3', bn: 'সংখ্যা পদ্ধতি ও ডিজিটাল ডিভাইস', en: 'Number System and Digital Devices' },
          { id: 'ict-4', bn: 'ওয়েব ডিজাইন পরিচিতি এবং HTML', en: 'Web Design and HTML' },
          { id: 'ict-5', bn: 'প্রোগ্রামিং ভাষা (C Programming)', en: 'Programming Language (C)' },
          { id: 'ict-6', bn: 'ডেটাবেজ ম্যানেজমেন্ট সিস্টেম', en: 'Database Management System' },
        ]
      }
    ]
  },
  {
    subjectId: 'english',
    name: 'ইংরেজি',
    papers: [
      {
        paper: '1st Paper',
        chapters: [
          { id: 'eng-1-1', bn: 'MCQ & Short Question', en: 'MCQ & Short Question' },
          { id: 'eng-1-2', bn: 'Flowchart', en: 'Flowchart' },
          { id: 'eng-1-3', bn: 'Summarising', en: 'Summarising' },
          { id: 'eng-1-4', bn: 'With Clue', en: 'With Clue' },
          { id: 'eng-1-5', bn: 'Without Clue', en: 'Without Clue' },
          { id: 'eng-1-6', bn: 'Rearrange', en: 'Rearrange' },
          { id: 'eng-1-7', bn: 'Paragraph', en: 'Paragraph' },
          { id: 'eng-1-8', bn: 'Information / Letter / Email', en: 'Information / Letter / Email' },
          { id: 'eng-1-9', bn: 'Graph / Charts', en: 'Graph / Charts' },
          { id: 'eng-1-10', bn: 'Story', en: 'Story' },
          { id: 'eng-1-11', bn: 'Poem', en: 'Poem' },
        ]
      },
      {
        paper: '2nd Paper',
        chapters: [
          { id: 'eng-2-1', bn: 'Gap Filling (without clues)', en: 'Gap Filling without Clues' },
          { id: 'eng-2-2', bn: 'Prepositions', en: 'Prepositions' },
          { id: 'eng-2-3', bn: 'Words and Phrases', en: 'Words and Phrases' },
          { id: 'eng-2-4', bn: 'Completing Sentences (Conditionals)', en: 'Completing Sentences' },
          { id: 'eng-2-5', bn: 'Right Form of Verbs', en: 'Right Form of Verbs' },
          { id: 'eng-2-6', bn: 'Changing Sentences (Voice, Degree)', en: 'Changing Sentences' },
          { id: 'eng-2-7', bn: 'Narrative Style', en: 'Narrative Style' },
          { id: 'eng-2-8', bn: 'Pronoun Reference / Modifiers', en: 'Pronoun Reference' },
          { id: 'eng-2-9', bn: 'Sentence Connectors', en: 'Sentence Connectors' },
          { id: 'eng-2-10', bn: 'Synonym and Antonym', en: 'Synonym and Antonym' },
          { id: 'eng-2-11', bn: 'Punctuation', en: 'Punctuation' },
          { id: 'eng-2-12', bn: 'Formal Letter / Application', en: 'Formal Letter / Application' },
          { id: 'eng-2-13', bn: 'Report Writing', en: 'Report Writing' },
          { id: 'eng-2-14', bn: 'Paragraph Writing', en: 'Paragraph Writing' },
          { id: 'eng-2-15', bn: 'Essay / Composition', en: 'Essay / Composition' },
        ]
      }
    ]
  },
  {
    subjectId: 'bangla',
    name: 'বাংলা',
    papers: [
      {
        paper: '1st Paper',
        chapters: [
          { id: 'ban-1-1', bn: 'বাঙলার নব্য লেখকদিগের প্রতি নিবেদন (বঙ্কিমচন্দ্র)', en: 'Bankimchandra - Prose 1' },
          { id: 'ban-1-2', bn: 'অপরিচিতা (রবীন্দ্রনাথ ঠাকুর)', en: 'Aparichita - Rabindranath' },
          { id: 'ban-1-3', bn: 'সাহিত্যে খেলা (প্রমথ চৌধুরী)', en: 'Pramatha Chowdhury - Prose' },
          { id: 'ban-1-4', bn: 'বিলাসী (শরৎচন্দ্র)', en: 'Bilasi - Saratchandra' },
          { id: 'ban-1-5', bn: 'অর্ধাঙ্গী (রোকেয়া সাখাওয়াত)', en: 'Ardhanghi - Rokeya' },
          { id: 'ban-1-6', bn: 'যৌবনের গান (কাজী নজরুল ইসলাম)', en: 'Youvaner Gaan - Nazrul' },
          { id: 'ban-1-7', bn: 'জীবন ও বৃক্ষ (মোতাহের হোসেন)', en: 'Jibon o Briksha' },
          { id: 'ban-1-8', bn: 'গন্তব্য কাবুল (সৈয়দ মুজতবা আলী)', en: 'Gontobyo Kabul' },
          { id: 'ban-1-9', bn: 'মাসি-পিসি (মানিক বন্দ্যোপাধ্যায়)', en: 'Masi Pisi - Manik' },
          { id: 'ban-1-10', bn: 'কপিলদাস মুর্মূর শেষ কাজ (মহাশ্বেতা দেবী)', en: 'Kapilas Murmu - Prose' },
          { id: 'ban-1-11', bn: 'রেইনকোট (আখতারুজ্জামান ইলিয়াস)', en: 'Raincoat - Ilius' },
          { id: 'ban-1-12', bn: 'নেকলেস (গুই দ্য মোপাসাঁ)', en: 'Necklace - Maupassant' },
          { id: 'ban-1-13', bn: 'ঋতু বর্ণন (কবিতা)', en: 'Ritu Bornan - Poetry' },
          { id: 'ban-1-14', bn: 'বিভীষণের প্রতি মেঘনাদ (মধুসূদন)', en: 'Bibhishan - Madhusudan' },
          { id: 'ban-1-15', bn: 'সোনার তরী (রবীন্দ্রনাথ)', en: 'Sonar Tori - Rabindranath' },
          { id: 'ban-1-16', bn: 'বিদ্রোহী (কাজী নজরুল ইসলাম)', en: 'Bidrohi - Nazrul' },
          { id: 'ban-1-17', bn: 'সুচেতনা (জীবনানন্দ দাশ)', en: 'Suchetana - Jibanananda' },
          { id: 'ban-1-18', bn: 'প্রতিদান (জসিমউদ্দীন)', en: 'Protidan - Jasimuddin' },
          { id: 'ban-1-19', bn: 'তাহারেই পড়ে মনে (সুফিয়া কামাল)', en: 'Taharei Pore Mone' },
          { id: 'ban-1-20', bn: 'পদ্মা (ফররুখ আহমদ)', en: 'Padma - Farrukh' },
          { id: 'ban-1-21', bn: 'আঠারো বছর বয়স (সুকান্ত)', en: 'Atharo Bochor Boyos' },
          { id: 'ban-1-22', bn: 'ফেব্রুয়ারি ১৯৬৯ (শামসুর রাহমান)', en: 'February 1969' },
          { id: 'ban-1-23', bn: 'আমি কিংবদন্তির কথা বলছি (আবু জাফর)', en: 'Ami Kingbodontir Kotha' },
          { id: 'ban-1-24', bn: 'প্রত্যাবর্তনের লজ্জা (কবিতা)', en: 'Protyabortonar Lojja' },
          { id: 'ban-1-25', bn: 'সিরাজউদ্দৌলা (নাটক)', en: 'Sirajuddaula - Drama' },
          { id: 'ban-1-26', bn: 'লালসালু (উপন্যাস)', en: 'Lalsalu - Novel' },
        ]
      },
      {
        paper: '2nd Paper',
        chapters: [
          { id: 'ban-2-1', bn: 'বাংলা উচ্চারণের নিয়ম', en: 'Bengali Pronunciation Rules' },
          { id: 'ban-2-2', bn: 'বাংলা বানানের নিয়ম', en: 'Bengali Spelling Rules' },
          { id: 'ban-2-3', bn: 'ব্যাকরণিক শব্দশ্রেণি', en: 'Word Classes' },
          { id: 'ban-2-4', bn: 'শব্দগঠন প্রক্রিয়া (উপসর্গ ও সমাস)', en: 'Word Formation' },
          { id: 'ban-2-5', bn: 'বাক্যতত্ত্ব', en: 'Sentence Structure' },
          { id: 'ban-2-6', bn: 'অপপ্রয়োগ ও শুদ্ধ প্রয়োগ', en: 'Correct Usage' },
          { id: 'ban-2-7', bn: 'পারিভাষিক শব্দ ও অনুবাদ', en: 'Technical Terms and Translation' },
          { id: 'ban-2-8', bn: 'দিনলিপি, ভাষণ ও প্রতিবেদন', en: 'Diary, Speech and Report' },
          { id: 'ban-2-9', bn: 'বৈদ্যুতিন চিঠি, পত্রলিখন ও আবেদনপত্র', en: 'Email, Letters and Applications' },
          { id: 'ban-2-10', bn: 'সারাংশ, সারমর্ম ও ভাব-সম্প্রসারণ', en: 'Summary and Expansion' },
          { id: 'ban-2-11', bn: 'সংলাপ ও খুদেগল্প', en: 'Dialogue and Short Story' },
          { id: 'ban-2-12', bn: 'প্রবন্ধ-নিবন্ধ রচনা', en: 'Essay Writing' },
        ]
      }
    ]
  }
];

// ✅ Get syllabus progress from localStorage
export const SYLLABUS_KEY = 'hsc-syllabus-progress';

export function getSyllabusProgress(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(SYLLABUS_KEY) || '{}');
  } catch {
    return {};
  }
}

export function toggleSyllabusChapter(chapterId: string): void {
  const progress = getSyllabusProgress();
  progress[chapterId] = !progress[chapterId];
  localStorage.setItem(SYLLABUS_KEY, JSON.stringify(progress));
  window.dispatchEvent(new Event('syllabus-updated'));
}

export function getSyllabusOverallPercent(): number {
  const progress = getSyllabusProgress();
  let total = 0;
  let done = 0;
  SYLLABUS_DATA.forEach(subject => {
    subject.papers.forEach(paper => {
      paper.chapters.forEach(ch => {
        total++;
        if (progress[ch.id]) done++;
      });
    });
  });
  return total > 0 ? Math.round((done / total) * 100) : 0;
}

export function getSubjectSyllabusPercent(subjectId: string): number {
  const progress = getSyllabusProgress();
  const subject = SYLLABUS_DATA.find(s => s.subjectId === subjectId);
  if (!subject) return 0;
  let total = 0;
  let done = 0;
  subject.papers.forEach(paper => {
    paper.chapters.forEach(ch => {
      total++;
      if (progress[ch.id]) done++;
    });
  });
  return total > 0 ? Math.round((done / total) * 100) : 0;
}
