// ✅ Books PDF Data — All subjects
// Credit: mulboi.com

export interface BookPDF {
  title: string;
  author: string;
  url: string;
  paper: string;
}

export interface SubjectBooks {
  subjectId: string;
  label: string;
  emoji: string;
  books: BookPDF[];
}

export const BOOKS_DATA: SubjectBooks[] = [
  {
    subjectId: 'bangla',
    label: 'Bangla',
    emoji: '🇧🇩',
    books: [
      { title: 'Bangla 1st Paper Main Book', author: 'NCTB', paper: '1st Paper', url: 'https://drive.google.com/file/d/11tNq5F0bfYFf5QexWOWAz3VlpryMlaFD/view' },
      { title: 'Bangla 1st Paper Guide', author: 'Supplement 2026', paper: '1st Paper', url: 'https://www.scribd.com/document/974679187/Hsc-Bangla-1st-Paper-Suppliment-2026' },
      { title: 'Bangla 2nd Paper', author: 'NCTB', paper: '2nd Paper', url: 'https://drive.google.com/file/d/1XptoxROJrvvJzCCsT6QIMYe6A85SGCjc/view' },
      { title: 'Bekaron Part (Folder)', author: 'NCTB', paper: '2nd Paper', url: 'https://drive.google.com/drive/u/0/folders/1RUCBSmGkAVwOFPM0OjVUwRq34c43KIUC' },
      { title: 'Sohopath', author: 'NCTB', paper: '1st Paper', url: 'https://drive.google.com/file/d/1xwZ1GmHSRS5v39YMnsz84DsvAq8enGIE/view' },
    ]
  },
  {
    subjectId: 'english',
    label: 'English',
    emoji: '🇬🇧',
    books: [
      { title: 'English for Today', author: 'NCTB', paper: '1st Paper', url: 'https://drive.google.com/file/d/1MJuzkvoyB57hueE2qasG3ou9nokQHY7T/view' },
      { title: 'HSC English 2nd Paper — All in One', author: 'Grammar Guide', paper: '2nd Paper', url: 'https://www.scribd.com/document/914289848/Hsc-English-2nd-Paper-All-in-One' },
    ]
  },
  {
    subjectId: 'ict',
    label: 'ICT',
    emoji: '💻',
    books: [
      { title: 'ICT Main Book', author: 'NCTB', paper: 'All Chapters', url: 'https://drive.google.com/file/d/16AVZQzh9LRq4_o238_bdM16jd57ZuNC8/view' },
      { title: 'Sohokari Book', author: 'Mahbubur Rahman Sir', paper: 'All Chapters', url: 'https://www.scribd.com/document/687433007/HSC-ICT-Book-by-Mahbubur-Rahman' },
    ]
  },
  {
    subjectId: 'physics',
    label: 'Physics',
    emoji: '⚡',
    books: [
      { title: '1st Paper', author: 'Ishak Sir', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/15' },
      { title: '2nd Paper', author: 'Ishak Sir', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/129' },
      { title: '1st Paper', author: 'Topon Sir', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/16' },
      { title: '2nd Paper', author: 'Topon Sir', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/130' },
    ]
  },
  {
    subjectId: 'math',
    label: 'Mathematics',
    emoji: '📐',
    books: [
      { title: '1st Paper', author: 'Ketab Uddin Sir', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/32' },
      { title: '2nd Paper', author: 'Ketab Uddin Sir', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/38' },
      { title: '1st Paper', author: 'Oshim Kumar Saha', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/33' },
      { title: '2nd Paper', author: 'Oshim Kumar Saha', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/414' },
      { title: '1st Paper', author: 'S.U. Ahmed', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/34' },
      { title: '2nd Paper', author: 'S.U. Ahmed', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/37' },
    ]
  },
  {
    subjectId: 'chemistry',
    label: 'Chemistry',
    emoji: '🧪',
    books: [
      { title: '1st Paper', author: 'Hazari Nag Sir', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/23' },
      { title: '2nd Paper', author: 'Hazari Nag Sir', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/31' },
      { title: '1st Paper', author: 'Sonjit Kumar Guho', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/25' },
      { title: '2nd Paper', author: 'Sonjit Kumar Guho', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/29' },
    ]
  },
  {
    subjectId: 'biology',
    label: 'Biology',
    emoji: '🧬',
    books: [
      { title: '1st Paper (Botany)', author: 'Hasan Sir', paper: '1st Paper', url: 'https://www.mulboi.com/book_bank/private_link/39' },
      { title: '2nd Paper (Zoology)', author: 'Gaji Ajmol Sir', paper: '2nd Paper', url: 'https://www.mulboi.com/book_bank/private_link/44' },
    ]
  },
];
