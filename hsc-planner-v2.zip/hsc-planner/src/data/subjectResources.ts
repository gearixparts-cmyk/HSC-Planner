import { 
  Calculator, 
  BookOpen, 
  Youtube, 
  FileText, 
  BrainCircuit, 
  Target, 
  Zap, 
  Atom, 
  FlaskConical, 
  Dna, 
  Laptop, 
  Languages, 
  Globe, 
  Lock 
} from 'lucide-react';

export type ResourceType = 'basic' | 'oneshot' | 'cq' | 'mcq' | 'special' | 'notes';

export interface Resource {
  id: string;
  title: string;
  teacher?: string;
  url: string;
  type: ResourceType;
}

export interface Paper {
  name: string;
  resources: {
    basic?: Resource[];
    oneshot?: Resource[];
    cq?: Resource[];
    mcq?: Resource[];
    special?: Resource[];
  };
}

export interface Subject {
  id: string;
  name: string;
  icon: any;
  channels?: { name: string; url: string }[];
  papers: Paper[];
  specialSection?: {
    title: string;
    url: string;
    icon: any;
  };
}

export const SUBJECT_RESOURCES: Subject[] = [
  {
    id: 'math',
    name: 'Mathematics',
    icon: Calculator,
    channels: [
      { name: 'Math & Science Nerds', url: 'https://www.youtube.com/@MathScienceNerds' },
      { name: 'Kamrul Islam', url: 'https://www.youtube.com/@kamrulislam' },
      { name: 'Abhi Datta Tushar', url: 'https://www.youtube.com/@abhidattatushar156' }
    ],
    papers: [
      {
        name: '1st Paper',
        resources: {
          basic: [
            { id: 'math-1-basic-full', title: '1st Paper Full Basic Playlist', url: 'https://www.youtube.com/playlist?list=PLF08hE3BZ41xoPqNlYHvmh3UbIJPlOTaJ', type: 'basic' }
          ],
          oneshot: [
            { id: 'math-1-oneshot', title: 'Oneshot Playlist', teacher: 'Math & Science Nerds', url: 'https://www.youtube.com/playlist?list=PLA-A92FsFtb9WE12mqRL_7N8q2JMkY6Ih', type: 'oneshot' }
          ],
          mcq: [
            { id: 'math-1-mcq-1', title: 'MCQ Playlist Option 1', teacher: 'Abhi Datta Tushar', url: 'https://www.youtube.com/playlist?list=PLF08hE3BZ41wk09u_umoMY9AuedOTA_9o', type: 'mcq' },
            { id: 'math-1-mcq-2', title: 'MCQ Playlist Option 2', url: 'https://www.youtube.com/playlist?list=PL4XrhAetwHqG9qz40qpVxL5n-tjbnzZro', type: 'mcq' }
          ],
          special: [
            { id: 'math-calc-hacks', title: 'Calculator Hacks', url: 'https://www.youtube.com/playlist?list=PLi5fEbOt0If7Opn9oYIqxEkWMxFYRpbQZ', type: 'special' }
          ]
        }
      },
      {
        name: '2nd Paper',
        resources: {
          basic: [
            { id: 'math-2-basic-full', title: '2nd Paper Full Basic Playlist', url: 'https://www.youtube.com/playlist?list=PLF08hE3BZ41z2h8gkF2FJ5FGeiChrWRJi', type: 'basic' }
          ],
          oneshot: [
            { id: 'math-2-oneshot', title: 'Oneshot Playlist', teacher: 'Math & Science Nerds', url: 'https://www.youtube.com/@MathScienceNerds', type: 'oneshot' }
          ],
          mcq: [
            { id: 'math-2-mcq', title: 'Use 1st Paper MCQ Playlists', url: 'https://www.youtube.com/playlist?list=PLF08hE3BZ41wk09u_umoMY9AuedOTA_9o', type: 'mcq' }
          ]
        }
      }
    ]
  },
  {
    id: 'physics',
    name: 'Physics',
    icon: Atom,
    channels: [
      { name: 'Physics Saviour', url: 'https://www.youtube.com/@ThePhysicsSaviour' }
    ],
    papers: [
      {
        name: '1st & 2nd Paper Resources',
        resources: {
          oneshot: [
            { id: 'phy-oneshot-main', title: 'Main Oneshot Playlist', teacher: 'Shahriar Nazim', url: 'https://www.youtube.com/playlist?list=PLl4LrmzTHWUQROW-5JhMftj3rEUI-rPB-', type: 'oneshot' },
            { id: 'phy-oneshot-add', title: 'Additional Oneshot Playlist', url: 'https://www.youtube.com/playlist?list=PLKjdwUViO6Fj0tALC2m6_ZXm8tE6f0b2_', type: 'oneshot' }
          ],
          cq: [
            { id: 'phy-concept', title: 'Chapter-wise Concept Playlists', url: 'https://www.youtube.com/@ThePhysicsSaviour/playlists', type: 'cq' },
            { id: 'phy-udvash', title: 'Udvash Concept Classes', url: 'https://www.youtube.com/results?search_query=Udvash+Physics+Concept+Classes', type: 'cq' }
          ],
          mcq: [
            { id: 'phy-mcq', title: 'MCQ Playlist', url: 'https://www.youtube.com/playlist?list=PLKjdwUViO6FiSSxNUjQOluph0F-djsqTT', type: 'mcq' }
          ]
        }
      }
    ]
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    icon: FlaskConical,
    channels: [
      { name: 'Aloronxyz', url: 'https://www.youtube.com/@aloronxyz' },
      { name: 'Bondi Pathshala', url: 'https://www.youtube.com/@bondipathshala' }
    ],
    papers: [
      {
        name: '1st Paper',
        resources: {
          basic: [
            { id: 'chem-1-ch1', title: 'Chapter 1 Basic', url: 'https://www.youtube.com/playlist?list=PL63A5sj8xSzSsQYbxVw2Qy9_dqndmeZJW', type: 'basic' },
            { id: 'chem-1-ch2', title: 'Chapter 2 Basic', url: 'https://youtu.be/VgEBQExGJtk', type: 'basic' },
            { id: 'chem-1-ch3', title: 'Chapter 3 Basic', url: 'https://youtu.be/DzWmJn8nVL4', type: 'basic' },
            { id: 'chem-1-ch4', title: 'Chapter 4 Basic', url: 'https://youtu.be/7bbhGbJv5xk', type: 'basic' }
          ],
          oneshot: [
            { id: 'chem-oneshot', title: 'Oneshot (CQ + MCQ)', teacher: 'AR Bhaiya', url: 'https://www.youtube.com/playlist?list=PLBIUjjCw0wBIkkofSaKgm5PszW58e4089', type: 'oneshot' }
          ]
        }
      },
      {
        name: '2nd Paper',
        resources: {
          basic: [
            { id: 'chem-2-ch1', title: 'Chapter 1 Basic', url: 'https://youtu.be/cnEPq4_J38Q', type: 'basic' },
            { id: 'chem-2-ch2', title: 'Chapter 2 Basic', url: 'https://www.youtube.com/playlist?list=PL8Rd-VjZUx02xnc5jK5cjux0RbEqnU9gN', type: 'basic' },
            { id: 'chem-2-ch3', title: 'Chapter 3 Basic', url: 'https://www.youtube.com/playlist?list=PL8Rd-VjZUx00Ecnply8uNE7Vzf24y59NU', type: 'basic' },
            { id: 'chem-2-ch4', title: 'Chapter 4 Basic', url: 'https://www.youtube.com/playlist?list=PL8Rd-VjZUx018Auyvlnvgp0uumR9SU39A', type: 'basic' }
          ]
        }
      }
    ]
  },
  {
    id: 'biology',
    name: 'Biology',
    icon: Dna,
    channels: [
      { name: 'Dr Abrar Hamim', url: 'https://www.youtube.com/@Master_biology' }
    ],
    papers: [
      {
        name: '1st & 2nd Paper Resources',
        resources: {
          oneshot: [
            { id: 'bio-oneshot-abrar', title: 'Oneshot Playlist', teacher: 'Dr Abrar Hamim', url: 'https://www.youtube.com/playlist?list=PLoYieD8GCtx_IMSAx9saIg82UHxNH-pLm', type: 'oneshot' },
            { id: 'bio-oneshot-udvash', title: 'Udvash Playlist', url: 'https://www.youtube.com/playlist?list=PLKjdwUViO6FjsbQdDMGnZ6s3tZGIeYFy0', type: 'oneshot' }
          ],
          mcq: [
            { id: 'bio-mcq', title: 'MCQ Playlist', url: 'https://www.youtube.com/playlist?list=PLKjdwUViO6Fi_zkPBfpP0vnLAr6lWssP1', type: 'mcq' }
          ]
        }
      }
    ]
  },
  {
    id: 'ict',
    name: 'ICT',
    icon: Laptop,
    papers: [
      {
        name: 'All Chapters',
        resources: {
          oneshot: [
            { id: 'ict-oneshot-1', title: 'Oneshot Playlist 1', url: 'https://www.youtube.com/playlist?list=PLi5fEbOt0If7Yo4Vt-G0q_byIKVzoFdxa', type: 'oneshot' },
            { id: 'ict-oneshot-2', title: 'Oneshot Playlist 2', url: 'https://www.youtube.com/playlist?list=PLersUpanCgbMHpp44hjCZy4tgdKFDvtJQ', type: 'oneshot' },
            { id: 'ict-oneshot-3', title: 'Oneshot Playlist 3', url: 'https://www.youtube.com/playlist?list=PLh2EsjwYJx7sKAX03HWTngODE-yj445Xl', type: 'oneshot' }
          ],
          mcq: [
            { id: 'ict-mcq', title: 'MCQ Playlist', url: 'https://www.youtube.com/playlist?list=PLszuMeoSBF0c2CU4UAae6dH9w3shsqIBE', type: 'mcq' }
          ]
        }
      }
    ]
  },
  {
    id: 'bangla',
    name: 'Bangla',
    icon: Languages,
    channels: [
      { name: 'Obelar Bangla', url: 'https://www.youtube.com/@ObelarBangla2021' },
      { name: 'Bangla Biddya', url: 'https://www.youtube.com/playlist?list=PLrRT7z4vncw_dQRdqagT2VF4BMI3Xmjni' }
    ],
    papers: [
      {
        name: '1st Paper',
        resources: {
          basic: [
            { id: 'ban-1-goddo', title: 'Goddo Playlist', teacher: 'Obelar Bangla', url: 'https://www.youtube.com/playlist?list=PL_j1rX-45PGZOovARVKb4HoXT3lMTRC3F', type: 'basic' },
            { id: 'ban-1-poddo', title: 'Poddo Playlist', teacher: 'Obelar Bangla', url: 'https://www.youtube.com/playlist?list=PL_j1rX-45PGYkrMQbwYrd5mMLiERifGfn', type: 'basic' },
            { id: 'ban-1-sohopath', title: 'Sohopath Playlist', teacher: 'Obelar Bangla', url: 'https://www.youtube.com/playlist?list=PL_j1rX-45PGYAxjgi51Zh6RB2_AE0u97V', type: 'basic' }
          ],
          mcq: [
            { id: 'ban-1-mcq', title: 'MCQ Playlist', teacher: 'Obelar Bangla', url: 'https://www.youtube.com/playlist?list=PL_j1rX-45PGZ-bXjPPjFFl2ILsNBgTLkh', type: 'mcq' }
          ]
        }
      },
      {
        name: '2nd Paper',
        resources: {
          basic: [
            { id: 'ban-2-banglabiddya', title: 'Bangla Biddya Playlist', url: 'https://www.youtube.com/playlist?list=PLrRT7z4vncw_dQRdqagT2VF4BMI3Xmjni', type: 'basic' },
            { id: 'ban-2-udvash', title: 'Udvash Playlist', url: 'https://www.youtube.com/playlist?list=PL3fBB5-oEa1ymekXzL_jqGurBD-KcZVcy', type: 'basic' },
            { id: 'ban-2-obelar', title: 'Obelar Bangla Playlist', url: 'https://www.youtube.com/playlist?list=PL_j1rX-45PGYuwybjotjmHD5c5m87RIK0', type: 'basic' }
          ]
        }
      }
    ]
  },
  {
    id: 'english',
    name: 'English',
    icon: Globe,
    channels: [
      { name: 'English Moja', url: 'https://www.youtube.com/@EnglishMoja' }
    ],
    papers: [
      {
        name: 'Resources',
        resources: {
          basic: [
            { id: 'eng-playlist-1', title: 'Batch Playlist 1', url: 'https://www.youtube.com/playlist?list=PL4gRuW3EKQHt3mIl_Q-NW_avQ_dliWNkl', type: 'basic' },
            { id: 'eng-playlist-2', title: 'Batch Playlist 2', url: 'https://www.youtube.com/playlist?list=PLCu0vqOHR8arGr7AhM3BiIdiZaOedWncM', type: 'basic' }
          ]
        }
      }
    ]
  }
];

export const SECRET_VAULT = {
  title: 'All Subject Hand Notes & Slides (Private Collection)',
  url: 'https://drive.google.com/drive/u/0/folders/1u8xdP7YgHhbYFsdOCMHyaHCMt69cm8eM',
  icon: Lock
};
