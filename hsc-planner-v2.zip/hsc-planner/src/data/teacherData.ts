// ✅ Teacher Panel Data — All subjects with direct YouTube playlist links

export interface Teacher {
  name: string;
  url: string;
  tagline: string;
  icon: string;
}

export interface TeacherSubject {
  subjectId: string;
  label: string;
  emoji: string;
  teachers: Teacher[];
}

export const TEACHER_DATA: TeacherSubject[] = [
  {
    subjectId: 'math',
    label: 'Mathematics',
    emoji: '📐',
    teachers: [
      { name: 'Math & Science Nerds', url: 'https://www.youtube.com/@MathScienceNerds/playlists', tagline: 'Best for Concept & Oneshot', icon: '🎯' },
      { name: 'Kamrul Islam', url: 'https://www.youtube.com/@kamrulislam/playlists', tagline: 'Best for Step-by-step Basics', icon: '📚' },
      { name: 'Abhi Datta Tushar', url: 'https://www.youtube.com/@abhidattatushar156/playlists', tagline: 'Best for MCQ Practice', icon: '⚡' },
    ]
  },
  {
    subjectId: 'biology',
    label: 'Biology',
    emoji: '🧬',
    teachers: [
      { name: 'Dr. Abrar Hamim', url: 'https://www.youtube.com/@Master_biology/playlists', tagline: 'Best for Concept + Oneshot', icon: '🔬' },
      { name: 'Hasnat Shuvro', url: 'https://www.youtube.com/@HasnatShuvro/playlists', tagline: 'Great for Zoology Topics', icon: '🦠' },
    ]
  },
  {
    subjectId: 'physics',
    label: 'Physics',
    emoji: '⚡',
    teachers: [
      { name: 'Physics Saviour', url: 'https://www.youtube.com/@ThePhysicsSaviour', tagline: 'Best for Concept & Oneshot', icon: '💡' },
      { name: 'Apurbo', url: 'https://www.youtube.com/@apurbophysics/playlists', tagline: 'Strong for Numerical Problems', icon: '🔢' },
      { name: 'Physics Vaiya', url: 'https://www.youtube.com/@PHYSICSvaiya05321/playlists', tagline: 'Great for Quick Revision', icon: '⚡' },
    ]
  },
  {
    subjectId: 'chemistry',
    label: 'Chemistry',
    emoji: '🧪',
    teachers: [
      { name: 'AloronXYZ', url: 'https://www.youtube.com/@aloronxyz/playlists', tagline: 'Best for Concept + MCQ + Oneshot', icon: '⚗️' },
      { name: 'AR Vaia (Bondhi Pathshala)', url: 'https://www.youtube.com/playlist?list=PLBIUjjCw0wBIkkofSaKgm5PszW58e4089', tagline: 'Excellent for Organic + 2nd Paper', icon: '🧫' },
    ]
  },
  {
    subjectId: 'ict',
    label: 'ICT',
    emoji: '💻',
    teachers: [
      { name: 'Math & Science Nerds', url: 'https://www.youtube.com/playlist?list=PLi5fEbOt0If7Yo4Vt-G0q_byIKVzoFdxa', tagline: 'Oneshot Playlist', icon: '🎯' },
      { name: 'Fahad Tutorials (Sany Sir)', url: 'https://www.youtube.com/playlist?list=PLh2EsjwYJx7u1CNOx2Hf6D3Ave676BopE', tagline: 'Oneshot Playlist', icon: '📱' },
      { name: 'HSC Crackers', url: 'https://www.youtube.com/playlist?list=PLersUpanCgbMHpp44hjCZy4tgdKFDvtJQ', tagline: 'MCQ + Quick Revision', icon: '🚀' },
    ]
  },
  {
    subjectId: 'english',
    label: 'English',
    emoji: '🇬🇧',
    teachers: [
      { name: 'English Moja', url: 'https://www.youtube.com/@EnglishMoja/playlists', tagline: 'Best for All English Topics', icon: '📝' },
    ]
  },
  {
    subjectId: 'bangla',
    label: 'Bangla',
    emoji: '🇧🇩',
    teachers: [
      { name: 'Obelar Bangla', url: 'https://www.youtube.com/@ObelarBangla2021/playlists', tagline: 'Best for 1st Paper (Prose + Poetry)', icon: '📖' },
      { name: 'বাংলা বিদ্যা', url: 'https://www.youtube.com/playlist?list=PLivTO2NHEJKYNY1gZ1FrY23Zw2OOaCwNr', tagline: 'Good for 2nd Paper', icon: '✍️' },
      { name: 'Nahid24', url: 'https://www.youtube.com/@Nahid24/playlists', tagline: 'Strong for 2nd Paper Grammar', icon: '🎓' },
      { name: 'Udvash', url: 'https://www.youtube.com/playlist?list=PL3fBB5-oEa1ymekXzL_jqGurBD-KcZVcy', tagline: 'Institutional Quality Content', icon: '🏫' },
    ]
  }
];
