import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { lazy, Suspense } from "react";
import Layout from "@/components/Layout";
import { AuthProvider } from "@/contexts/AuthContext";

const Dashboard = lazy(() => import("@/pages/Dashboard"));
const Planner = lazy(() => import("@/pages/Planner"));
const Subjects = lazy(() => import("@/pages/Subjects"));
const SubjectDetail = lazy(() => import("@/pages/SubjectDetail"));
const Calendar = lazy(() => import("@/pages/Calendar"));
const Weekly = lazy(() => import("@/pages/Weekly"));
const Settings = lazy(() => import("@/pages/Settings"));
const PomodoroPage = lazy(() => import("@/pages/PomodoroPage"));
const TeacherPanel = lazy(() => import("@/pages/TeacherPanel"));
const BooksPage = lazy(() => import("@/pages/BooksPage"));
const CalculatorPage = lazy(() => import("@/pages/CalculatorPage"));
const WhiteboardPage = lazy(() => import("@/pages/WhiteboardPage"));
const SubjectSearch = lazy(() => import("@/pages/SubjectSearch"));

const PageLoader = () => (
  <div className="flex items-center justify-center min-h-[50vh]">
    <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
  </div>
);

// Whiteboard uses full screen — no Layout wrapper
function WhiteboardRoute() {
  return (
    <Suspense fallback={<PageLoader />}>
      <WhiteboardPage />
    </Suspense>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Whiteboard is full screen */}
          <Route path="/whiteboard" element={<WhiteboardRoute />} />
          {/* Everything else uses Layout */}
          <Route path="/*" element={
            <Layout>
              <Suspense fallback={<PageLoader />}>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/planner" element={<Planner />} />
                  <Route path="/planner/:date" element={<Planner />} />
                  <Route path="/subjects" element={<Subjects />} />
                  <Route path="/subjects/:id" element={<SubjectDetail />} />
                  <Route path="/calendar" element={<Calendar />} />
                  <Route path="/weekly" element={<Weekly />} />
                  <Route path="/pomodoro" element={<PomodoroPage />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/teachers" element={<TeacherPanel />} />
                  <Route path="/books" element={<BooksPage />} />
                  <Route path="/calculator" element={<CalculatorPage />} />
                  <Route path="/search" element={<SubjectSearch />} />
                </Routes>
              </Suspense>
            </Layout>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
