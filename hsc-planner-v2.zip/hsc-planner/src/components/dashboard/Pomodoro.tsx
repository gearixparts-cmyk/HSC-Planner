import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Settings, Volume2, VolumeX, X, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { checkBadges } from '@/lib/gamification';

type TimerMode = 'pomodoro' | 'shortBreak' | 'longBreak';

export default function Pomodoro({ isStatic = false }: { isStatic?: boolean }) {
  const [mode, setMode] = useState<TimerMode>('pomodoro');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [isExpanded, setIsExpanded] = useState(isStatic);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Settings
  const [pomodoroTime, setPomodoroTime] = useState(25);
  const [shortBreakTime, setShortBreakTime] = useState(5);
  const [longBreakTime, setLongBreakTime] = useState(15);
  const [autoStartBreaks, setAutoStartBreaks] = useState(false);
  const [autoStartPomodoros, setAutoStartPomodoros] = useState(false);

  const [sessions, setSessions] = useState(() => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const saved = localStorage.getItem(`pomodoro-${today}`);
      return saved ? parseInt(saved) : 0;
    } catch (e) {
      return 0;
    }
  });

  // Track sessions for smart break
  const [sessionsSinceLongBreak, setSessionsSinceLongBreak] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio
    audioRef.current = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
  }, []);

  useEffect(() => {
    try {
      const today = new Date().toISOString().split('T')[0];
      localStorage.setItem(`pomodoro-${today}`, sessions.toString());
    } catch (e) {
      console.error("Failed to save pomodoro sessions", e);
    }
  }, [sessions]);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      // Timer finished
      handleTimerComplete();
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const switchMode = (newMode: TimerMode) => {
    setMode(newMode);
    setIsActive(false);
    switch (newMode) {
      case 'pomodoro':
        setTimeLeft(pomodoroTime * 60);
        break;
      case 'shortBreak':
        setTimeLeft(shortBreakTime * 60);
        break;
      case 'longBreak':
        setTimeLeft(longBreakTime * 60);
        break;
    }
  };

  const handleTimerComplete = () => {
    setIsActive(false);
    if (soundEnabled && audioRef.current) {
      audioRef.current.play().catch(e => console.error("Audio play failed", e));
    }

    if (mode === 'pomodoro') {
      setSessions(s => s + 1);
      setSessionsSinceLongBreak(s => s + 1);
      toast.success("Focus session complete!");
      
      // Check badges
      setTimeout(() => checkBadges(), 100);

      if (autoStartBreaks) {
        // Smart Break Logic
        if (sessionsSinceLongBreak + 1 >= 4) {
          switchMode('longBreak');
          setSessionsSinceLongBreak(0);
          toast.info("Great job! Take a long break.");
        } else {
          switchMode('shortBreak');
        }
        setIsActive(true);
      }
    } else {
      toast.success("Break over! Time to focus.");
      if (autoStartPomodoros) {
        switchMode('pomodoro');
        setIsActive(true);
      }
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    switch (mode) {
      case 'pomodoro':
        setTimeLeft(pomodoroTime * 60);
        break;
      case 'shortBreak':
        setTimeLeft(shortBreakTime * 60);
        break;
      case 'longBreak':
        setTimeLeft(longBreakTime * 60);
        break;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    const total = mode === 'pomodoro' ? pomodoroTime * 60 : mode === 'shortBreak' ? shortBreakTime * 60 : longBreakTime * 60;
    return ((total - timeLeft) / total) * 100;
  };

  // Render logic
  if (isStatic) {
    return (
      <div className="w-full max-w-md mx-auto bg-surface border border-border rounded-2xl shadow-2xl overflow-hidden animate-in fade-in duration-500">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-border bg-surface-alt">
          <h3 className="font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-white" /> Pomofocus
          </h3>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setSettingsOpen(!settingsOpen)}
              className="p-2 text-secondary hover:text-white transition-colors rounded-lg hover:bg-white/10"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Settings View */}
        {settingsOpen ? (
          <div className="p-6 space-y-6">
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-secondary uppercase tracking-wider">Timer (minutes)</h4>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-xs text-muted block mb-1">Pomodoro</label>
                  <input 
                    type="number" 
                    value={pomodoroTime} 
                    onChange={(e) => setPomodoroTime(Number(e.target.value))}
                    className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted block mb-1">Short Break</label>
                  <input 
                    type="number" 
                    value={shortBreakTime} 
                    onChange={(e) => setShortBreakTime(Number(e.target.value))}
                    className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted block mb-1">Long Break</label>
                  <input 
                    type="number" 
                    value={longBreakTime} 
                    onChange={(e) => setLongBreakTime(Number(e.target.value))}
                    className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Auto-start Breaks</span>
                <input 
                  type="checkbox" 
                  checked={autoStartBreaks} 
                  onChange={(e) => setAutoStartBreaks(e.target.checked)}
                  className="accent-white h-5 w-5"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Auto-start Pomodoros</span>
                <input 
                  type="checkbox" 
                  checked={autoStartPomodoros} 
                  onChange={(e) => setAutoStartPomodoros(e.target.checked)}
                  className="accent-white h-5 w-5"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Sound</span>
                <button onClick={() => setSoundEnabled(!soundEnabled)}>
                  {soundEnabled ? <Volume2 className="h-5 w-5 text-white" /> : <VolumeX className="h-5 w-5 text-muted" />}
                </button>
              </div>
            </div>

            <button 
              onClick={() => {
                setSettingsOpen(false);
                resetTimer(); // Apply new times
              }}
              className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Save Settings
            </button>
          </div>
        ) : (
          /* Timer View */
          <div className="p-6 flex flex-col items-center">
            {/* Mode Switcher */}
            <div className="flex bg-surface-alt p-1 rounded-full mb-8 w-full max-w-xs">
              <button 
                onClick={() => switchMode('pomodoro')}
                className={cn(
                  "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                  mode === 'pomodoro' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                )}
              >
                Pomodoro
              </button>
              <button 
                onClick={() => switchMode('shortBreak')}
                className={cn(
                  "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                  mode === 'shortBreak' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                )}
              >
                Short Break
              </button>
              <button 
                onClick={() => switchMode('longBreak')}
                className={cn(
                  "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                  mode === 'longBreak' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                )}
              >
                Long Break
              </button>
            </div>

            {/* Big Timer */}
            <div className="text-6xl md:text-8xl font-mono font-bold text-white mb-8 tracking-tighter">
              {formatTime(timeLeft)}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-6 mb-8">
              <button 
                onClick={toggleTimer}
                className={cn(
                  "h-20 w-20 rounded-3xl flex items-center justify-center transition-all shadow-lg hover:scale-105 active:scale-95",
                  isActive ? "bg-surface-alt border-2 border-white text-white" : "bg-white text-black"
                )}
              >
                {isActive ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8 ml-1" />}
              </button>
              
              <button 
                onClick={resetTimer}
                className="h-14 w-14 rounded-2xl bg-surface-alt border border-border text-white flex items-center justify-center hover:bg-border transition-colors"
              >
                <RotateCcw className="h-6 w-6" />
              </button>
            </div>

            <div className="text-sm text-secondary">
              Sessions today: <span className="text-white font-bold text-lg ml-2">{sessions}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <>
      {/* Minimized Floating Button */}
      <div 
        className={cn(
          "fixed bottom-24 right-4 md:bottom-8 md:right-8 z-50 transition-all duration-300",
          isExpanded ? "scale-0 opacity-0 pointer-events-none" : "scale-100 opacity-100"
        )}
      >
        <button
          onClick={() => setIsExpanded(true)}
          className="w-16 h-16 bg-surface border border-border rounded-full shadow-2xl flex items-center justify-center relative overflow-hidden group hover:scale-105 transition-transform"
        >
          <svg className="w-full h-full transform -rotate-90 absolute inset-0">
             <circle cx="32" cy="32" r="28" stroke="#232323" strokeWidth="4" fill="transparent" />
             <circle 
               cx="32" cy="32" r="28" 
               stroke={mode === 'pomodoro' ? '#FFFFFF' : '#A0A0A0'} 
               strokeWidth="4" 
               fill="transparent" 
               strokeDasharray={175.9}
               strokeDashoffset={175.9 * (1 - getProgress() / 100)}
               className="transition-all duration-1000"
             />
           </svg>
           <div className="relative z-10 flex flex-col items-center">
             {isActive ? <Pause className="h-6 w-6 text-white" /> : <Play className="h-6 w-6 text-white ml-1" />}
             <span className="text-[10px] font-mono font-bold text-white mt-1">{formatTime(timeLeft)}</span>
           </div>
        </button>
      </div>

      {/* Expanded Dashboard Panel */}
      {isExpanded && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[101] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-surface border border-border rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b border-border bg-surface-alt">
              <h3 className="font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-white" /> Pomofocus
              </h3>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setSettingsOpen(!settingsOpen)}
                  className="p-2 text-secondary hover:text-white transition-colors rounded-lg hover:bg-white/10"
                >
                  <Settings className="h-5 w-5" />
                </button>
                <button 
                  onClick={() => setIsExpanded(false)}
                  className="p-2 text-secondary hover:text-white transition-colors rounded-lg hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Settings View */}
            {settingsOpen ? (
              <div className="p-6 space-y-6">
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-secondary uppercase tracking-wider">Timer (minutes)</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-xs text-muted block mb-1">Pomodoro</label>
                      <input 
                        type="number" 
                        value={pomodoroTime} 
                        onChange={(e) => setPomodoroTime(Number(e.target.value))}
                        className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted block mb-1">Short Break</label>
                      <input 
                        type="number" 
                        value={shortBreakTime} 
                        onChange={(e) => setShortBreakTime(Number(e.target.value))}
                        className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted block mb-1">Long Break</label>
                      <input 
                        type="number" 
                        value={longBreakTime} 
                        onChange={(e) => setLongBreakTime(Number(e.target.value))}
                        className="w-full bg-surface-alt border border-border rounded-lg p-2 text-white text-center"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-white">Auto-start Breaks</span>
                    <input 
                      type="checkbox" 
                      checked={autoStartBreaks} 
                      onChange={(e) => setAutoStartBreaks(e.target.checked)}
                      className="accent-white h-5 w-5"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-white">Auto-start Pomodoros</span>
                    <input 
                      type="checkbox" 
                      checked={autoStartPomodoros} 
                      onChange={(e) => setAutoStartPomodoros(e.target.checked)}
                      className="accent-white h-5 w-5"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-white">Sound</span>
                    <button onClick={() => setSoundEnabled(!soundEnabled)}>
                      {soundEnabled ? <Volume2 className="h-5 w-5 text-white" /> : <VolumeX className="h-5 w-5 text-muted" />}
                    </button>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    setSettingsOpen(false);
                    resetTimer(); // Apply new times
                  }}
                  className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Save Settings
                </button>
              </div>
            ) : (
              /* Timer View */
              <div className="p-6 flex flex-col items-center">
                {/* Mode Switcher */}
                <div className="flex bg-surface-alt p-1 rounded-full mb-8 w-full max-w-xs">
                  <button 
                    onClick={() => switchMode('pomodoro')}
                    className={cn(
                      "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                      mode === 'pomodoro' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                    )}
                  >
                    Pomodoro
                  </button>
                  <button 
                    onClick={() => switchMode('shortBreak')}
                    className={cn(
                      "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                      mode === 'shortBreak' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                    )}
                  >
                    Short Break
                  </button>
                  <button 
                    onClick={() => switchMode('longBreak')}
                    className={cn(
                      "flex-1 py-2 text-xs font-bold rounded-full transition-all",
                      mode === 'longBreak' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-white"
                    )}
                  >
                    Long Break
                  </button>
                </div>

                {/* Big Timer */}
                <div className="text-6xl md:text-8xl font-mono font-bold text-white mb-8 tracking-tighter">
                  {formatTime(timeLeft)}
                </div>

                {/* Controls */}
                <div className="flex items-center gap-6 mb-8">
                  <button 
                    onClick={toggleTimer}
                    className={cn(
                      "h-20 w-20 rounded-3xl flex items-center justify-center transition-all shadow-lg hover:scale-105 active:scale-95",
                      isActive ? "bg-surface-alt border-2 border-white text-white" : "bg-white text-black"
                    )}
                  >
                    {isActive ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8 ml-1" />}
                  </button>
                  
                  <button 
                    onClick={resetTimer}
                    className="h-14 w-14 rounded-2xl bg-surface-alt border border-border text-white flex items-center justify-center hover:bg-border transition-colors"
                  >
                    <RotateCcw className="h-6 w-6" />
                  </button>
                </div>

                <div className="text-sm text-secondary">
                  Sessions today: <span className="text-white font-bold text-lg ml-2">{sessions}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
