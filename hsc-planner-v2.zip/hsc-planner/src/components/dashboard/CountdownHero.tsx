import { useState, useEffect } from 'react';
import { differenceInDays, differenceInWeeks } from 'date-fns';
import { useBatch } from '@/hooks/useBatch';
import { getSyllabusOverallPercent } from '@/data/syllabusData';

export default function CountdownHero() {
  const { batchYear } = useBatch();
  const [days, setDays] = useState(0);
  const [weeks, setWeeks] = useState(0);
  const [percent, setPercent] = useState(0);

  const targetYear = batchYear || 2026;

  const calc = () => {
    const today = new Date();
    today.setHours(0,0,0,0);
    // ✅ 16 July — month index 6 = July
    const exam = new Date(targetYear, 6, 16);
    setDays(Math.max(0, differenceInDays(exam, today)));
    setWeeks(Math.max(0, differenceInWeeks(exam, today)));
    setPercent(getSyllabusOverallPercent());
  };

  useEffect(() => {
    calc();
    const t = setInterval(calc, 60000);
    window.addEventListener('syllabus-updated', calc);
    return () => { clearInterval(t); window.removeEventListener('syllabus-updated', calc); };
  }, [targetYear]);

  const examPassed = new Date() > new Date(targetYear, 6, 16);

  if (examPassed) {
    return (
      <div className="w-full bg-surface border border-border p-6 mb-6 rounded-xl text-center">
        <div className="text-3xl font-bold text-white mb-2">🎓 Exam Completed!</div>
        <p className="text-secondary text-sm">Best of luck for your results!</p>
      </div>
    );
  }

  return (
    <div className="w-full bg-surface border border-border p-5 md:p-7 mb-6 rounded-xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-secondary text-xs uppercase tracking-widest mb-1">HSC {targetYear} Board Exam</h2>
          <div className="text-3xl md:text-4xl font-bold text-white tracking-tight">16 July {targetYear}</div>
        </div>
        <div className="flex w-full md:w-auto justify-between md:justify-end gap-5 md:gap-8 border-t border-border/50 pt-3 md:border-0 md:pt-0">
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-white tabular-nums">{days}</div>
            <div className="text-[10px] text-secondary uppercase tracking-wider">Days Left</div>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-white tabular-nums">{weeks}</div>
            <div className="text-[10px] text-secondary uppercase tracking-wider">Weeks</div>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-white tabular-nums">{percent}%</div>
            <div className="text-[10px] text-secondary uppercase tracking-wider">Syllabus</div>
          </div>
        </div>
      </div>
      <div className="mt-5">
        <div className="flex justify-between text-[10px] text-secondary mb-1.5">
          <span>Syllabus Progress (tick chapters to update)</span>
          <span>{percent}%</span>
        </div>
        <div className="h-1.5 w-full bg-surface-alt rounded-full overflow-hidden">
          <div className="h-full bg-white rounded-full transition-all duration-700 ease-out" style={{ width: `${percent}%` }} />
        </div>
      </div>
    </div>
  );
}
