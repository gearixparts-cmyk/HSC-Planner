import { useState, FormEvent } from 'react';
import { format } from 'date-fns';
import { Plus, Check, Trash2 } from 'lucide-react';
import { useTasks } from '@/hooks/useTasks';
import { cn } from '@/lib/utils';

export default function FocusCard() {
  const today = format(new Date(), 'yyyy-MM-dd');
  const { tasks, addTask, toggleTask, deleteTask } = useTasks(today);
  const [newTask, setNewTask] = useState('');

  const progress = tasks.length > 0 ? Math.round((tasks.filter(t => t.completed).length / tasks.length) * 100) : 0;

  const handleAdd = (e: FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    addTask(newTask);
    setNewTask('');
  };

  return (
    <div className="bg-surface border border-border rounded-xl p-4 md:p-6 mb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-3 md:gap-0">
        <div>
          <h3 className="text-lg font-bold text-white">Today's Focus</h3>
          <p className="text-xs md:text-sm text-secondary">{format(new Date(), 'EEEE, d MMMM yyyy')}</p>
        </div>
        <div className="flex items-center justify-between md:block bg-surface-alt/30 p-2 rounded-lg md:bg-transparent md:p-0">
          <span className="text-xs text-secondary md:hidden">Progress</span>
          <div className="text-right flex items-baseline gap-2 md:block">
            <div className="text-xl md:text-2xl font-bold text-white">{progress}%</div>
            <div className="text-xs text-secondary hidden md:block">Done</div>
          </div>
        </div>
      </div>

      <div className="h-2 w-full bg-surface-alt rounded-full mb-6 overflow-hidden">
        <div className="h-full bg-white transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>

      <form onSubmit={handleAdd} className="flex gap-2 mb-4">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task..."
          className="flex-1 bg-surface-alt border border-border rounded-lg px-4 py-3 md:py-2 text-sm text-white focus:outline-none focus:border-white transition-colors"
        />
        <button
          type="submit"
          className="bg-white text-black rounded-lg px-4 py-2 hover:bg-gray-200 transition-colors flex items-center justify-center min-w-[44px]"
        >
          <Plus className="h-5 w-5" />
        </button>
      </form>

      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
        {tasks.length === 0 && (
          <p className="text-center text-muted text-sm py-4">No tasks yet. Add your first task.</p>
        )}
        {tasks.map((task) => (
          <div
            key={task.id}
            className="group flex items-center gap-3 p-3 rounded-lg hover:bg-surface-alt transition-colors"
          >
            <button
              onClick={() => toggleTask(task.id)}
              className={cn(
                "h-5 w-5 rounded border flex items-center justify-center transition-all",
                task.completed ? "bg-white border-white" : "border-secondary hover:border-white"
              )}
            >
              {task.completed && <Check className="h-3 w-3 text-black" />}
            </button>
            <span className={cn("flex-1 text-sm", task.completed && "line-through text-muted")}>
              {task.text}
            </span>
            <button
              onClick={() => deleteTask(task.id)}
              className="opacity-0 group-hover:opacity-100 text-muted hover:text-danger transition-all"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
