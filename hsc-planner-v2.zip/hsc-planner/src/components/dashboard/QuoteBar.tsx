import { useState, useEffect } from 'react';
import { QUOTES } from '@/lib/data';

export default function QuoteBar() {
  const [quote, setQuote] = useState('');

  useEffect(() => {
    // Rotate quote based on day of year to be consistent for the day
    const dayOfYear = Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24);
    setQuote(QUOTES[dayOfYear % QUOTES.length]);
  }, []);

  return (
    <div className="border-l-2 border-muted pl-4 py-2 my-6 italic text-secondary text-sm">
      "{quote}"
    </div>
  );
}
