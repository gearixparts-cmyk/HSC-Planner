import { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getSubjectProgress, getOverallProgress, SubjectProgressData } from '@/lib/progress';

export default function SubjectProgress() {
  const [isOpen, setIsOpen] = useState(true);
  const [progressData, setProgressData] = useState<SubjectProgressData[]>([]);
  const [overallProgress, setOverallProgress] = useState(0);

  useEffect(() => {
    const updateProgress = () => {
      setProgressData(getSubjectProgress());
      setOverallProgress(getOverallProgress());
    };

    updateProgress();

    // Listen for storage events to update progress in real-time
    window.addEventListener('storage', updateProgress);
    window.addEventListener('local-storage-update', updateProgress);
    
    return () => {
      window.removeEventListener('storage', updateProgress);
      window.removeEventListener('local-storage-update', updateProgress);
    };
  }, []);

  return (
    <div className="bg-surface border border-border rounded-xl overflow-hidden mb-24 md:mb-6">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-6 hover:bg-surface-alt transition-colors"
      >
        <div className="flex flex-col items-start">
          <h3 className="text-lg font-bold text-white">Subject Progress</h3>
          <p className="text-xs text-secondary mt-1">Overall Completion: {overallProgress}%</p>
        </div>
        {isOpen ? <ChevronUp className="h-5 w-5 text-secondary" /> : <ChevronDown className="h-5 w-5 text-secondary" />}
      </button>

      {isOpen && (
        <div className="px-6 pb-6 space-y-4">
          {/* Overall Progress Bar */}
          <div className="mb-6">
            <div className="h-2 w-full bg-surface-alt rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-1000 ease-out" 
                style={{ width: `${overallProgress}%` }}
              />
            </div>
          </div>

          {progressData.map((subject) => (
            <Link to={`/subjects`} key={subject.id} className="block group">
              <div className="flex justify-between items-center mb-2">
                <div>
                  <span className="text-sm font-medium text-white group-hover:text-secondary transition-colors">
                    {subject.name}
                  </span>
                  <span className="text-xs text-muted block">
                    {subject.completedResources}/{subject.totalResources} completed
                  </span>
                </div>
                <span className="text-sm font-mono text-secondary">{subject.percentage}%</span>
              </div>
              <div className="h-1 w-full bg-surface-alt rounded-full overflow-hidden">
                <div 
                  className="h-full bg-white transition-all duration-500" 
                  style={{ width: `${subject.percentage}%` }}
                />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
