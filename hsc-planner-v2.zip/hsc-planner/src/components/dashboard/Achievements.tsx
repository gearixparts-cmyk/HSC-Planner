import { useGamification } from '@/hooks/useGamification';
import { cn } from '@/lib/utils';
import { Trophy, Flame, Zap } from 'lucide-react';

export default function Achievements() {
  const { unlockedBadges, taskStreak, pomodoroStreak, badges } = useGamification();

  return (
    <div className="bg-surface border border-border rounded-xl p-4 md:p-6 mb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-3 md:gap-0">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-400" />
          Achievements
        </h3>
        <div className="flex gap-4 text-xs md:text-sm bg-surface-alt/50 p-2 rounded-lg md:bg-transparent md:p-0 w-full md:w-auto justify-around md:justify-start">
          <div className="flex items-center gap-1 text-orange-400">
            <Flame className="h-4 w-4" />
            <span className="font-mono font-bold">{taskStreak}</span> <span className="hidden sm:inline">Day Streak</span><span className="sm:hidden">Day</span>
          </div>
          <div className="flex items-center gap-1 text-blue-400">
            <Zap className="h-4 w-4" />
            <span className="font-mono font-bold">{pomodoroStreak}</span> <span className="hidden sm:inline">Focus Streak</span><span className="sm:hidden">Focus</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 md:gap-3">
        {badges.map((badge) => {
          const isUnlocked = unlockedBadges.includes(badge.id);
          return (
            <div 
              key={badge.id}
              className={cn(
                "flex flex-col items-center justify-center p-2 md:p-3 rounded-xl border transition-all duration-300 group relative min-h-[80px]",
                isUnlocked 
                  ? "bg-surface-alt border-yellow-500/20 hover:border-yellow-500/40" 
                  : "bg-surface border-border opacity-40 grayscale"
              )}
              title={badge.description}
            >
              <div className="text-xl md:text-2xl mb-1 filter drop-shadow-lg">{badge.icon}</div>
              <div className="text-[9px] md:text-[10px] text-center font-medium leading-tight text-secondary group-hover:text-white transition-colors line-clamp-2">
                {badge.name}
              </div>
              
              {/* Tooltip for desktop */}
              <div className="absolute bottom-full mb-2 hidden md:group-hover:block w-32 bg-black text-white text-xs p-2 rounded-lg z-10 pointer-events-none shadow-xl border border-white/10">
                {badge.description}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
