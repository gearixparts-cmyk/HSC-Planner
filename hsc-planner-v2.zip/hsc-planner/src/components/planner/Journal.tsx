import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface JournalEntry {
  studied: string;
  goal: string;
  rating: number;
  mood: 'focused' | 'normal' | 'low_energy';
}

export default function Journal({ date }: { date: string }) {
  const [entry, setEntry] = useState<JournalEntry>(() => {
    try {
      const saved = localStorage.getItem(`journal-${date}`);
      return saved ? JSON.parse(saved) : { studied: '', goal: '', rating: 0, mood: 'normal' };
    } catch (e) {
      console.error("Failed to parse journal entry", e);
      return { studied: '', goal: '', rating: 0, mood: 'normal' };
    }
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setSaving(true);
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(`journal-${date}`, JSON.stringify(entry));
        setSaving(false);
      } catch (e) {
        console.error("Failed to save journal entry", e);
        setSaving(false);
      }
    }, 1000); // Debounce save

    return () => clearTimeout(timer);
  }, [entry, date]);

  // Reset entry when date changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`journal-${date}`);
      setEntry(saved ? JSON.parse(saved) : { studied: '', goal: '', rating: 0, mood: 'normal' });
    } catch (e) {
      console.error("Failed to load journal entry on date change", e);
      setEntry({ studied: '', goal: '', rating: 0, mood: 'normal' });
    }
  }, [date]);

  return (
    <div className="space-y-6">
      <div className="bg-surface border border-border rounded-xl p-6">
        <h3 className="text-lg font-bold mb-4 text-white">Study Journal</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-xs text-secondary uppercase tracking-wider mb-2">What I studied today...</label>
            <textarea
              value={entry.studied}
              onChange={(e) => setEntry({ ...entry, studied: e.target.value })}
              className="w-full bg-surface-alt border border-border rounded-lg p-3 text-sm text-white focus:outline-none focus:border-white transition-colors min-h-[100px]"
              placeholder="Topics covered, concepts learned..."
            />
          </div>
          
          <div>
            <label className="block text-xs text-secondary uppercase tracking-wider mb-2">Tomorrow's goal...</label>
            <textarea
              value={entry.goal}
              onChange={(e) => setEntry({ ...entry, goal: e.target.value })}
              className="w-full bg-surface-alt border border-border rounded-lg p-3 text-sm text-white focus:outline-none focus:border-white transition-colors min-h-[70px]"
              placeholder="Key objectives for tomorrow..."
            />
          </div>
        </div>
        
        <div className="mt-2 text-right text-xs text-secondary">
          {saving ? "Saving..." : "Saved ✓"}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-surface border border-border rounded-xl p-6">
          <h3 className="text-sm font-bold mb-4 text-white">Productivity Rating</h3>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => setEntry({ ...entry, rating })}
                className={cn(
                  "flex-1 h-10 rounded-lg border transition-all font-mono font-bold",
                  entry.rating === rating
                    ? "bg-white text-black border-white"
                    : "bg-transparent text-secondary border-border hover:border-white"
                )}
              >
                {rating}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-surface border border-border rounded-xl p-6">
          <h3 className="text-sm font-bold mb-4 text-white">Mood</h3>
          <div className="flex gap-2">
            {[
              { id: 'focused', label: '😤 Focused' },
              { id: 'normal', label: '😐 Normal' },
              { id: 'low_energy', label: '😴 Low' },
            ].map((mood) => (
              <button
                key={mood.id}
                onClick={() => setEntry({ ...entry, mood: mood.id as any })}
                className={cn(
                  "flex-1 h-10 rounded-lg border transition-all text-xs font-medium",
                  entry.mood === mood.id
                    ? "bg-white text-black border-white"
                    : "bg-transparent text-secondary border-border hover:border-white"
                )}
              >
                {mood.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
