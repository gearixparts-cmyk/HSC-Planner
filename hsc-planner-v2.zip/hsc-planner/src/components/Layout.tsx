import { Link, useLocation } from "react-router-dom";
import { Home, ListTodo, BookOpen, CalendarDays, Database, Settings, Timer, GraduationCap, FileText, Search, Calculator, PenLine } from "lucide-react";
import { cn } from "@/lib/utils";
import { Toaster } from "sonner";
import Footer from "@/components/Footer";
import BatchSelectorModal from "@/components/BatchSelectorModal";
import { ReactNode, useEffect } from "react";
import { initNotifications } from '@/lib/notifications';

export default function Layout({ children }: { children: ReactNode }) {
  const location = useLocation();

  useEffect(() => {
    const interval = initNotifications();
    return () => { if (interval) clearInterval(interval); };
  }, []);

  // ✅ Scroll to top on page change — fixes the "opens at bottom" issue
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [location.pathname]);

  const mainNav = [
    { icon: Home, label: "Dashboard", path: "/" },
    { icon: ListTodo, label: "Planner", path: "/planner" },
    { icon: BookOpen, label: "Subjects", path: "/subjects" },
    { icon: CalendarDays, label: "Calendar", path: "/calendar" },
    { icon: Database, label: "All Data", path: "/weekly" },
    { icon: Timer, label: "Pomodoro", path: "/pomodoro" },
  ];

  const sideExtra = [
    { icon: GraduationCap, label: "Teacher Panel", path: "/teachers" },
    { icon: Search, label: "Subject Search", path: "/search" },
    { icon: FileText, label: "Books PDF", path: "/books" },
    { icon: Calculator, label: "Calculator", path: "/calculator" },
    { icon: PenLine, label: "Whiteboard", path: "/whiteboard" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  const isActive = (path: string) =>
    path === "/" ? location.pathname === "/" : location.pathname.startsWith(path);

  return (
    <div className="min-h-screen bg-background text-primary pb-20 md:pb-0 md:pl-64 transition-all duration-300 flex flex-col">

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed left-0 top-0 h-full w-64 flex-col border-r border-border bg-surface p-4 z-50 overflow-y-auto">
        <div className="mb-6">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="text-left hover:opacity-80 transition-opacity">
            <h1 className="text-xl font-bold tracking-tighter">HSC Planner</h1>
            <p className="text-xs text-muted-foreground mt-0.5">v2.0 — Bangladesh</p>
          </button>
        </div>

        <nav className="flex-1 space-y-1">
          <p className="text-[10px] text-secondary uppercase tracking-widest px-3 mb-2 mt-1">Main</p>
          {mainNav.map(item => (
            <Link key={item.path} to={item.path}
              className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                isActive(item.path) ? "bg-white text-black" : "text-secondary hover:bg-surface-alt hover:text-white")}>
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
          <p className="text-[10px] text-secondary uppercase tracking-widest px-3 mb-2 mt-4">Tools</p>
          {sideExtra.map(item => (
            <Link key={item.path} to={item.path}
              className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                isActive(item.path) ? "bg-white text-black" : "text-secondary hover:bg-surface-alt hover:text-white")}>
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-surface sticky top-0 z-40">
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="text-left">
          <h1 className="text-lg font-bold tracking-tighter">HSC Planner</h1>
        </button>
        <div className="flex gap-2">
          <Link to="/calculator" className={cn("p-2 rounded-lg transition-colors", isActive('/calculator') ? 'bg-white text-black' : 'hover:bg-surface-alt')}>
            <Calculator className="h-4 w-4" />
          </Link>
          <Link to="/settings" className={cn("p-2 rounded-lg transition-colors", isActive('/settings') ? 'bg-white text-black' : 'hover:bg-surface-alt')}>
            <Settings className="h-4 w-4" />
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 container mx-auto max-w-2xl p-4 md:p-8 animate-in fade-in duration-300">
        {children}
        <Footer />
      </main>

      <Toaster position="top-center" theme="dark" />
      <BatchSelectorModal />

      {/* Mobile Bottom Nav — 6 main items */}
      <nav className="fixed bottom-0 left-0 right-0 z-[100] flex h-16 items-center justify-around border-t border-border bg-surface/95 backdrop-blur md:hidden px-1">
        {mainNav.map(item => {
          const active = isActive(item.path);
          return (
            <Link key={item.path} to={item.path}
              className={cn("flex flex-col items-center justify-center gap-0.5 p-2 transition-all min-w-[50px]",
                active ? "text-white" : "text-muted-foreground hover:text-secondary")}>
              <item.icon className={cn("h-5 w-5 transition-all", active && "scale-110")} strokeWidth={active ? 2.5 : 1.8} />
              <span className={cn("text-[9px] font-medium transition-all", active && "font-bold")}>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Mobile Extra Tools Row */}
      <div className="fixed bottom-16 left-0 right-0 z-[99] flex h-10 items-center justify-around border-t border-border/50 bg-surface/80 backdrop-blur md:hidden px-2">
        {sideExtra.map(item => {
          const active = isActive(item.path);
          return (
            <Link key={item.path} to={item.path}
              className={cn("flex items-center gap-1 px-2 py-1 rounded-lg transition-all text-[10px]",
                active ? "text-white bg-white/10" : "text-muted-foreground hover:text-white")}>
              <item.icon className="h-3.5 w-3.5" strokeWidth={active ? 2.5 : 1.8} />
              <span className="hidden xs:inline">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
