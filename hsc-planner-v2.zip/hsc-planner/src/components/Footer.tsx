import { ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="w-full py-6 mt-12 border-t border-[#232323] text-center text-xs text-[#A0A0A0]">
      <div className="flex flex-col items-center justify-center gap-2">
        <p>© 2026 HSC Planner. All rights reserved.</p>
        <p className="flex items-center gap-1">
          Built & Maintained by{' '}
          <a
            href="https://www.tonmoy.shop/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#A0A0A0] hover:text-white transition-colors flex items-center gap-0.5 border-b border-transparent hover:border-white/20 pb-0.5"
          >
            Mohammad Tonmoy
            <ExternalLink className="h-2.5 w-2.5 opacity-50" />
          </a>
        </p>
      </div>
    </footer>
  );
}
