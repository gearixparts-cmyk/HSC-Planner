import { ExternalLink, Plus, Check, PlayCircle, FileText, BrainCircuit, Target, Zap, Lock } from 'lucide-react';
import { Resource, ResourceType } from '@/data/subjectResources';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useCompletedResources } from '@/hooks/useCompletedResources';

interface ResourceListProps {
  resources: Resource[];
  paperName: string;
}

export default function ResourceList({ resources, paperName }: ResourceListProps) {
  const { completedResources, toggleResource } = useCompletedResources();

  const toggleComplete = (id: string) => {
    toggleResource(id);
    if (!completedResources.includes(id)) {
      toast.success('Resource marked as completed!');
    }
  };

  const addToTasks = (resource: Resource) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const tasksKey = `tasks-${today}`;
      const savedTasks = localStorage.getItem(tasksKey);
      const tasks = savedTasks ? JSON.parse(savedTasks) : [];
      
      const newTask = {
        id: crypto.randomUUID(),
        text: `Watch ${resource.title} (${paperName})`,
        completed: false,
        date: today
      };
      
      localStorage.setItem(tasksKey, JSON.stringify([...tasks, newTask]));
      toast.success('Added to today\'s tasks');
      
      // Dispatch a storage event so other components can update if they listen
      window.dispatchEvent(new Event('storage'));
    } catch (e) {
      console.error(e);
      toast.error('Failed to add task');
    }
  };

  const getIcon = (type: ResourceType) => {
    switch (type) {
      case 'basic': return PlayCircle;
      case 'oneshot': return Zap;
      case 'cq': return BrainCircuit;
      case 'mcq': return Target;
      case 'special': return FileText;
      case 'notes': return Lock;
      default: return ExternalLink;
    }
  };

  const getTypeLabel = (type: ResourceType) => {
    switch (type) {
      case 'basic': return 'Basic Playlist';
      case 'oneshot': return 'Oneshot';
      case 'cq': return 'Concept / CQ';
      case 'mcq': return 'MCQ';
      case 'special': return 'Special';
      case 'notes': return 'Notes';
      default: return 'Resource';
    }
  };

  const getTypeColor = (type: ResourceType) => {
    switch (type) {
      case 'basic': return 'text-blue-400 border-blue-400/20 bg-blue-400/5';
      case 'oneshot': return 'text-yellow-400 border-yellow-400/20 bg-yellow-400/5';
      case 'cq': return 'text-purple-400 border-purple-400/20 bg-purple-400/5';
      case 'mcq': return 'text-red-400 border-red-400/20 bg-red-400/5';
      case 'special': return 'text-emerald-400 border-emerald-400/20 bg-emerald-400/5';
      default: return 'text-secondary border-border bg-surface-alt';
    }
  };

  return (
    <div className="grid gap-3">
      {resources.map((resource) => {
        const Icon = getIcon(resource.type);
        const isCompleted = completedResources.includes(resource.id);
        
        return (
          <div 
            key={resource.id}
            className={cn(
              "group relative flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border transition-all duration-300",
              isCompleted 
                ? "bg-surface-alt/50 border-border opacity-75" 
                : "bg-surface border-border hover:border-white/20"
            )}
          >
            <div className="flex items-start gap-3">
              <div className={cn("p-2 rounded-lg shrink-0", getTypeColor(resource.type))}>
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className={cn("text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border", getTypeColor(resource.type))}>
                    {getTypeLabel(resource.type)}
                  </span>
                  {resource.teacher && (
                    <span className="text-[10px] text-secondary bg-surface-alt px-1.5 py-0.5 rounded border border-border">
                      {resource.teacher}
                    </span>
                  )}
                </div>
                <h4 className={cn("font-medium text-sm sm:text-base", isCompleted && "line-through text-muted")}>
                  {resource.title}
                </h4>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-2 sm:mt-0 self-end sm:self-center">
              <button
                onClick={() => addToTasks(resource)}
                className="p-2 text-secondary hover:text-white hover:bg-surface-alt rounded-lg transition-colors"
                title="Add to Today's Tasks"
              >
                <Plus className="h-4 w-4" />
              </button>
              
              <button
                onClick={() => toggleComplete(resource.id)}
                className={cn(
                  "p-2 rounded-lg transition-colors",
                  isCompleted 
                    ? "text-green-400 bg-green-400/10 hover:bg-green-400/20" 
                    : "text-secondary hover:text-white hover:bg-surface-alt"
                )}
                title={isCompleted ? "Mark as Incomplete" : "Mark as Completed"}
              >
                <Check className="h-4 w-4" />
              </button>

              <a
                href={resource.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-lg text-xs font-bold hover:bg-gray-200 transition-colors"
              >
                Open
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        );
      })}
    </div>
  );
}
