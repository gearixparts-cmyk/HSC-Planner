import { useState, useEffect } from 'react';
import { CheckCircle2, Circle, ChevronDown, ChevronUp, BookOpen } from 'lucide-react';
import { SubjectSyllabus, getSyllabusProgress, toggleSyllabusChapter, getSubjectSyllabusPercent } from '@/data/syllabusData';
import { cn } from '@/lib/utils';

interface SyllabusPanelProps {
  syllabus: SubjectSyllabus;
}

export default function SyllabusPanel({ syllabus }: SyllabusPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activePaper, setActivePaper] = useState(syllabus.papers[0]?.paper || '');
  const [progress, setProgress] = useState<Record<string, boolean>>({});
  const [percent, setPercent] = useState(0);

  const refresh = () => {
    setProgress(getSyllabusProgress());
    setPercent(getSubjectSyllabusPercent(syllabus.subjectId));
  };

  useEffect(() => {
    refresh();
    window.addEventListener('syllabus-updated', refresh);
    return () => window.removeEventListener('syllabus-updated', refresh);
  }, [syllabus.subjectId]);

  const handleTick = (id: string) => {
    toggleSyllabusChapter(id);
    refresh();
  };

  const currentPaper = syllabus.papers.find(p => p.paper === activePaper);
  const doneInPaper = currentPaper?.chapters.filter(c => progress[c.id]).length || 0;
  const totalInPaper = currentPaper?.chapters.length || 0;

  return (
    <div className="border border-border rounded-xl bg-surface mt-2 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-surface-alt rounded-lg">
            <BookOpen className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-left">
            <span className="font-bold text-sm text-white">Syllabus</span>
            <div className="flex items-center gap-2 mt-0.5">
              <div className="h-1 w-24 bg-surface-alt rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-400 transition-all duration-500"
                  style={{ width: `${percent}%` }}
                />
              </div>
              <span className="text-[11px] text-emerald-400 font-mono font-bold">{percent}%</span>
            </div>
          </div>
        </div>
        <div className={cn("transition-transform duration-200", isOpen && "rotate-180")}>
          <ChevronDown className="h-4 w-4 text-secondary" />
        </div>
      </button>

      {isOpen && (
        <div className="border-t border-border bg-surface-alt/20 p-4 space-y-4 animate-in fade-in duration-200">
          {/* Paper tabs */}
          <div className="flex gap-2 flex-wrap">
            {syllabus.papers.map(p => (
              <button
                key={p.paper}
                onClick={() => setActivePaper(p.paper)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-bold transition-all border",
                  activePaper === p.paper
                    ? "bg-emerald-400 text-black border-emerald-400"
                    : "bg-surface border-border text-secondary hover:text-white"
                )}
              >
                {p.paper}
              </button>
            ))}
          </div>

          {/* Progress for active paper */}
          <div className="text-xs text-secondary mb-2">
            {doneInPaper}/{totalInPaper} chapters completed
          </div>

          {/* Chapter list */}
          <div className="space-y-2">
            {currentPaper?.chapters.map((ch, idx) => {
              const done = !!progress[ch.id];
              return (
                <button
                  key={ch.id}
                  onClick={() => handleTick(ch.id)}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200 active:scale-[0.99]",
                    done
                      ? "bg-emerald-500/10 border-emerald-500/30"
                      : "bg-surface border-border hover:border-white/20"
                  )}
                >
                  <div className="shrink-0">
                    {done
                      ? <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                      : <Circle className="h-5 w-5 text-secondary" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={cn(
                      "text-sm font-medium leading-snug",
                      done ? "text-emerald-400 line-through opacity-70" : "text-white"
                    )}>
                      <span className="text-secondary mr-1">{idx + 1}.</span>
                      {ch.bn}
                    </div>
                    <div className="text-[11px] text-secondary mt-0.5">{ch.en}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
