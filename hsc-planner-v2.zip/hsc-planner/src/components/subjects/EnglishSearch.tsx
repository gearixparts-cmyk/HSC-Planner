import { useState, FormEvent } from 'react';
import { Search, ExternalLink } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function EnglishSearch() {
  const [query, setQuery] = useState('');

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    const searchUrl = `https://www.youtube.com/results?search_query=HSC+English+${encodeURIComponent(query)}+by+English+Moja`;
    window.open(searchUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="bg-surface border border-border rounded-xl p-6 space-y-4">
      <div className="flex items-center gap-3 mb-2">
        <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg">
          <Search className="h-5 w-5" />
        </div>
        <div>
          <h3 className="font-bold text-lg">Smart Topic Search</h3>
          <p className="text-xs text-secondary">Find any English topic by English Moja instantly</p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="relative group">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. Narration, Modifiers, Right Form of Verbs..."
          className="w-full bg-surface-alt border border-border rounded-lg py-3 pl-4 pr-12 text-sm focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 transition-all placeholder:text-muted"
        />
        <button
          type="submit"
          disabled={!query.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-white text-black rounded-md hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <ExternalLink className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
