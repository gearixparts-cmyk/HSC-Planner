import { useState } from 'react';
import { ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { Subject, Paper } from '@/data/subjectResources';
import ResourceList from './ResourceList';
import SyllabusPanel from './SyllabusPanel';
import { SYLLABUS_DATA } from '@/data/syllabusData';
import { cn } from '@/lib/utils';

interface SubjectCardProps {
  subject: Subject;
}

export default function SubjectCard({ subject }: SubjectCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activePaper, setActivePaper] = useState<string | null>(subject.papers[0]?.name || null);

  const toggleOpen = () => setIsOpen(!isOpen);

  const handlePaperClick = (paperName: string) => {
    if (activePaper === paperName) {
      setActivePaper(null);
    } else {
      setActivePaper(paperName);
    }
  };

  return (
    <div className="border border-border rounded-xl bg-surface overflow-hidden transition-all duration-300 hover:border-white/10">
      <button
        onClick={toggleOpen}
        className="w-full flex items-center justify-between p-4 sm:p-6 bg-surface hover:bg-surface-alt transition-colors group"
      >
        <div className="flex items-center gap-4">
          <div className="p-3 bg-surface-alt rounded-xl group-hover:bg-white group-hover:text-black transition-colors">
            <subject.icon className="h-6 w-6" />
          </div>
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl text-white group-hover:text-white transition-colors">
              {subject.name}
            </h3>
            <div className="flex flex-wrap gap-2 mt-1">
              {subject.channels?.map((channel, idx) => (
                <a
                  key={idx}
                  href={channel.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="text-[10px] text-secondary hover:text-blue-400 flex items-center gap-1 transition-colors"
                >
                  {channel.name}
                  <ExternalLink className="h-2 w-2" />
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className={cn("transition-transform duration-300", isOpen && "rotate-180")}>
          <ChevronDown className="h-5 w-5 text-secondary" />
        </div>
      </button>

      <div 
        className={cn(
          "grid transition-all duration-300 ease-in-out",
          isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        )}
      >
        <div className="overflow-hidden">
          <div className="p-4 sm:p-6 border-t border-border bg-surface-alt/30 space-y-6">
            
            {/* Paper Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {subject.papers.map((paper) => (
                <button
                  key={paper.name}
                  onClick={() => handlePaperClick(paper.name)}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm font-bold whitespace-nowrap transition-all border",
                    activePaper === paper.name
                      ? "bg-white text-black border-white"
                      : "bg-surface border-border text-secondary hover:text-white hover:border-white/20"
                  )}
                >
                  {paper.name}
                </button>
              ))}
            </div>

            {/* Resources for Active Paper */}
            {activePaper && (
              <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                {subject.papers
                  .filter(p => p.name === activePaper)
                  .map((paper) => (
                    <div key={paper.name} className="space-y-8">
                      {paper.resources.basic && paper.resources.basic.length > 0 && (
                        <section>
                          <h4 className="text-xs font-bold text-secondary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                            Basic Concepts
                          </h4>
                          <ResourceList resources={paper.resources.basic} paperName={paper.name} />
                        </section>
                      )}

                      {paper.resources.oneshot && paper.resources.oneshot.length > 0 && (
                        <section>
                          <h4 className="text-xs font-bold text-secondary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                            Oneshot Revisions
                          </h4>
                          <ResourceList resources={paper.resources.oneshot} paperName={paper.name} />
                        </section>
                      )}

                      {paper.resources.cq && paper.resources.cq.length > 0 && (
                        <section>
                          <h4 className="text-xs font-bold text-secondary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                            Creative Questions (CQ)
                          </h4>
                          <ResourceList resources={paper.resources.cq} paperName={paper.name} />
                        </section>
                      )}

                      {paper.resources.mcq && paper.resources.mcq.length > 0 && (
                        <section>
                          <h4 className="text-xs font-bold text-secondary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                            MCQ Practice
                          </h4>
                          <ResourceList resources={paper.resources.mcq} paperName={paper.name} />
                        </section>
                      )}

                      {paper.resources.special && paper.resources.special.length > 0 && (
                        <section>
                          <h4 className="text-xs font-bold text-secondary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            Special Tools
                          </h4>
                          <ResourceList resources={paper.resources.special} paperName={paper.name} />
                        </section>
                      )}
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
