// AI Assistant removed in v2.0
export default function AIAssistant() { return null; }
