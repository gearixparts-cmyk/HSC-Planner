// APK popup disabled — no real APK available yet.
// When you have a real APK hosted at a working URL, re-enable this component.
// To re-enable: set REAL_APK_URL below and set APK_READY = true

const APK_READY = false; // ← Set to true when real APK is hosted
const REAL_APK_URL = 'https://hscbd.shop/HSC-Planner.apk'; // ← Your real APK URL

export default function ApkDownloadPopup() {
  // Do not show anything until real APK is ready
  if (!APK_READY) return null;

  return null;
}
