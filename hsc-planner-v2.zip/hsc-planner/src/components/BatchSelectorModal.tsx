import { useEffect } from 'react';
import { useBatch, BATCH_KEY } from '@/hooks/useBatch';

// Auto-sets batch to 2026 if not already set. No popup shown.
export default function BatchSelectorModal() {
  const { setBatch } = useBatch();

  useEffect(() => {
    const saved = localStorage.getItem(BATCH_KEY);
    if (!saved) {
      setBatch(2026);
    }
  }, []);

  return null;
}
