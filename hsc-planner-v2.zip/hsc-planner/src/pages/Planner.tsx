import { useParams, useNavigate } from 'react-router-dom';
import { format, parseISO, addDays, subDays } from 'date-fns';
import { ChevronLeft, ChevronRight, Save } from 'lucide-react';
import Journal from '@/components/planner/Journal';
import { useTasks } from '@/hooks/useTasks';
import { cn } from '@/lib/utils';
import React, { useState, FormEvent } from 'react';
import { Plus, Check, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const TaskManager: React.FC<{ date: string }> = ({ date }) => {
  const { tasks, addTask, toggleTask, deleteTask } = useTasks(date);
  const [newTask, setNewTask] = useState('');

  const handleAdd = (e: FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    addTask(newTask);
    setNewTask('');
  };

  return (
    <div className="bg-surface border border-border rounded-xl p-6 mb-6">
      <h3 className="text-lg font-bold text-white mb-4">Tasks</h3>
      
      <form onSubmit={handleAdd} className="flex gap-2 mb-4">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add a new task..."
          className="flex-1 bg-surface-alt border border-border rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-white transition-colors"
        />
        <button
          type="submit"
          className="bg-white text-black rounded-lg px-4 py-2 hover:bg-gray-200 transition-colors"
        >
          <Plus className="h-5 w-5" />
        </button>
      </form>

      <div className="space-y-2">
        {tasks.length === 0 && (
          <p className="text-center text-muted text-sm py-4">No tasks for this day.</p>
        )}
        {tasks.map((task) => (
          <div
            key={task.id}
            className="group flex items-center gap-3 p-3 rounded-lg hover:bg-surface-alt transition-colors"
          >
            <button
              onClick={() => toggleTask(task.id)}
              className={cn(
                "h-5 w-5 rounded border flex items-center justify-center transition-all",
                task.completed ? "bg-white border-white" : "border-secondary hover:border-white"
              )}
            >
              {task.completed && <Check className="h-3 w-3 text-black" />}
            </button>
            <span className={cn("flex-1 text-sm", task.completed && "line-through text-muted")}>
              {task.text}
            </span>
            <button
              onClick={() => deleteTask(task.id)}
              className="opacity-0 group-hover:opacity-100 text-muted hover:text-danger transition-all"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Planner() {
  const { date } = useParams();
  const navigate = useNavigate();
  
  // Default to today if no date param
  const currentDateStr = date || format(new Date(), 'yyyy-MM-dd');
  const currentDate = parseISO(currentDateStr);
  
  const handlePrevDay = () => {
    navigate(`/planner/${format(subDays(currentDate, 1), 'yyyy-MM-dd')}`);
  };
  
  const handleNextDay = () => {
    navigate(`/planner/${format(addDays(currentDate, 1), 'yyyy-MM-dd')}`);
  };

  const EXAM_DATE = new Date('2026-06-26');
  const START_DATE = new Date('2026-03-01');
  const dayNumber = Math.floor((currentDate.getTime() - START_DATE.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  const totalDays = Math.floor((EXAM_DATE.getTime() - START_DATE.getTime()) / (1000 * 60 * 60 * 24));

  const handleSaveAll = () => {
    // Visual confirmation since data is auto-saved
    toast.success("All planner data saved successfully!");
  };

  return (
    <div className="pb-24 animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-8">
        <button onClick={handlePrevDay} className="p-2 hover:bg-surface-alt rounded-full transition-colors">
          <ChevronLeft className="h-5 w-5 text-white" />
        </button>
        
        <div className="text-center">
          <div className="text-xs text-secondary uppercase tracking-widest mb-1">
            Day {dayNumber} of {totalDays}
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-white">
            {format(currentDate, 'EEEE, d MMMM yyyy')}
          </h1>
        </div>

        <button onClick={handleNextDay} className="p-2 hover:bg-surface-alt rounded-full transition-colors">
          <ChevronRight className="h-5 w-5 text-white" />
        </button>
      </div>

      <div className="flex justify-end mb-4">
        <button 
          onClick={handleSaveAll}
          className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-200 transition-colors shadow-lg"
        >
          <Save className="h-4 w-4" />
          Save All
        </button>
      </div>

      <TaskManager key={currentDateStr} date={currentDateStr} />
      <Journal date={currentDateStr} />
    </div>
  );
}
