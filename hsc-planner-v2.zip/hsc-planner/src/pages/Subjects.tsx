import { SUBJECT_RESOURCES, SECRET_VAULT } from '@/data/subjectResources';
import SubjectCard from '@/components/subjects/SubjectCard';
import EnglishSearch from '@/components/subjects/EnglishSearch';
import { useNavigate } from 'react-router-dom';
import { ExternalLink, TrendingUp, Search, GraduationCap } from 'lucide-react';
import { getOverallProgress } from '@/lib/progress';
import { useCompletedResources } from '@/hooks/useCompletedResources';

export default function Subjects() {
  const navigate = useNavigate();
  const { completedResources } = useCompletedResources();
  const overallProgress = getOverallProgress();

  return (
    <div className="space-y-8 pb-24 animate-in fade-in duration-500">
      <div className="space-y-4">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Subject Resource Hub</h1>
          <p className="text-secondary text-sm">
            Comprehensive collection of playlists, oneshots, and tools for HSC 2026.
          </p>

          {/* Quick links */}
          <div className="flex gap-2 mt-2">
            <button onClick={() => navigate('/search')}
              className="flex items-center gap-2 px-4 py-2 bg-surface border border-border rounded-xl text-sm hover:border-white/20 hover:bg-surface-alt transition-colors">
              <Search className="h-4 w-4 text-blue-400" /> Subject Search
            </button>
            <button onClick={() => navigate('/teachers')}
              className="flex items-center gap-2 px-4 py-2 bg-surface border border-border rounded-xl text-sm hover:border-white/20 hover:bg-surface-alt transition-colors">
              <GraduationCap className="h-4 w-4 text-yellow-400" /> Teacher Panel
            </button>
          </div>
        </div>

        {/* Overall Progress */}
        <div className="bg-surface border border-border rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-surface-alt rounded-full">
            <TrendingUp className="h-6 w-6 text-green-400" />
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-white">Overall Syllabus Progress</span>
              <span className="text-sm font-bold text-green-400">{overallProgress}%</span>
            </div>
            <div className="h-2 w-full bg-surface-alt rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-400 transition-all duration-1000 ease-out" 
                style={{ width: `${overallProgress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Secret Vault */}
      <a
        href={SECRET_VAULT.url}
        target="_blank"
        rel="noopener noreferrer"
        className="block group relative overflow-hidden rounded-xl border border-border bg-surface p-6 hover:border-white/20 transition-all duration-300"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-surface-alt rounded-xl group-hover:bg-white group-hover:text-black transition-colors">
              <SECRET_VAULT.icon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white group-hover:text-white transition-colors">
                {SECRET_VAULT.title}
              </h3>
              <p className="text-xs text-secondary mt-1">
                Exclusive hand notes, slides, and premium materials
              </p>
            </div>
          </div>
          <ExternalLink className="h-5 w-5 text-secondary group-hover:text-white transition-colors" />
        </div>
      </a>

      {/* Subjects Grid */}
      <div className="grid gap-6">
        {SUBJECT_RESOURCES.map((subject) => (
          <div key={subject.id} className="space-y-4">
            <SubjectCard subject={subject} />
            {subject.id === 'english' && (
              <div className="pl-4 border-l-2 border-border ml-4">
                <EnglishSearch />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
