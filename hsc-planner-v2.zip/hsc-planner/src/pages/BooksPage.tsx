import { useState } from 'react';
import { ExternalLink, BookOpen, ChevronLeft } from 'lucide-react';
import { BOOKS_DATA, SubjectBooks } from '@/data/booksData';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function BooksPage() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<SubjectBooks | null>(null);

  if (selected) {
    return (
      <div className="pb-24 animate-in fade-in slide-in-from-right-4 duration-300">
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => setSelected(null)} className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">{selected.emoji} {selected.label}</h1>
            <p className="text-secondary text-sm">Click to open PDF — Credit: mulboi.com</p>
          </div>
        </div>
        <div className="space-y-3">
          {selected.books.map((book, idx) => (
            <a key={idx} href={book.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 bg-surface border border-border rounded-xl hover:border-white/20 hover:bg-surface-alt transition-all group active:scale-[0.99]">
              <div className="p-3 bg-surface-alt rounded-xl group-hover:bg-white group-hover:text-black transition-colors shrink-0">
                <BookOpen className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sm text-white">{book.title}</div>
                <div className="text-xs text-secondary mt-0.5">{book.author} • {book.paper}</div>
              </div>
              <div className="flex items-center gap-1 text-xs font-bold bg-white text-black px-3 py-1.5 rounded-lg group-hover:bg-gray-200 transition-colors shrink-0">
                Open <ExternalLink className="h-3 w-3 ml-1" />
              </div>
            </a>
          ))}
        </div>
        <p className="text-center text-xs text-secondary mt-8">
          PDF Credit: <a href="https://www.mulboi.com/" target="_blank" rel="noopener noreferrer" className="underline hover:text-white">mulboi.com</a>
        </p>
      </div>
    );
  }

  return (
    <div className="pb-24 animate-in fade-in duration-300">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/')} className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-blue-400" /> Books PDF
          </h1>
          <p className="text-secondary text-sm">All HSC textbooks — free PDF</p>
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {BOOKS_DATA.map((subject) => (
          <button key={subject.subjectId} onClick={() => setSelected(subject)}
            className="flex flex-col items-center justify-center gap-2 p-5 bg-surface border border-border rounded-xl hover:border-white/20 hover:bg-surface-alt transition-all active:scale-[0.98] text-center">
            <span className="text-3xl">{subject.emoji}</span>
            <span className="font-bold text-sm text-white">{subject.label}</span>
            <span className="text-[11px] text-secondary">{subject.books.length} books</span>
          </button>
        ))}
      </div>
      <p className="text-center text-xs text-secondary mt-8">
        PDF Credit: <a href="https://www.mulboi.com/" target="_blank" rel="noopener noreferrer" className="underline hover:text-white">mulboi.com</a>
      </p>
    </div>
  );
}
