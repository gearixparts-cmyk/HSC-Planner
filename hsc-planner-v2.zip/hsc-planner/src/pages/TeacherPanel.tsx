import { useState } from 'react';
import { ExternalLink, ChevronLeft, GraduationCap } from 'lucide-react';
import { TEACHER_DATA, TeacherSubject } from '@/data/teacherData';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function TeacherPanel() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<TeacherSubject | null>(null);

  if (selected) {
    return (
      <div className="pb-24 animate-in fade-in slide-in-from-right-4 duration-300">
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => setSelected(null)}
            className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">{selected.emoji} {selected.label}</h1>
            <p className="text-secondary text-sm">Best teachers — click to open playlist</p>
          </div>
        </div>

        <div className="space-y-3">
          {selected.teachers.map((teacher, idx) => (
            <a
              key={idx}
              href={teacher.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 bg-surface border border-border rounded-xl hover:border-white/20 hover:bg-surface-alt transition-all duration-200 group active:scale-[0.99]"
            >
              <div className="text-2xl w-10 h-10 flex items-center justify-center bg-surface-alt rounded-xl shrink-0">
                {teacher.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-white group-hover:text-white">{teacher.name}</div>
                <div className="text-xs text-secondary mt-0.5">{teacher.tagline}</div>
              </div>
              <div className="flex items-center gap-2 bg-white text-black px-3 py-2 rounded-lg text-xs font-bold group-hover:bg-gray-200 transition-colors shrink-0">
                Visit
                <ExternalLink className="h-3 w-3" />
              </div>
            </a>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 animate-in fade-in duration-300">
      <div className="flex items-center gap-3 mb-2">
        <button
          onClick={() => navigate('/')}
          className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-yellow-400" />
            Teacher Panel
          </h1>
          <p className="text-secondary text-sm">Select a subject to see the best teachers</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6">
        {TEACHER_DATA.map((subject) => (
          <button
            key={subject.subjectId}
            onClick={() => setSelected(subject)}
            className="flex flex-col items-center justify-center gap-2 p-5 bg-surface border border-border rounded-xl hover:border-white/20 hover:bg-surface-alt transition-all duration-200 active:scale-[0.98] text-center"
          >
            <span className="text-3xl">{subject.emoji}</span>
            <span className="font-bold text-sm text-white">{subject.label}</span>
            <span className="text-[11px] text-secondary">{subject.teachers.length} teachers</span>
          </button>
        ))}
      </div>
    </div>
  );
}
