import { useRef, useState, useEffect, useCallback } from 'react';
import { ChevronLeft, Plus, Trash2, Download, Pencil, Eraser, Minus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import jsPDF from 'jspdf';

type Tool = 'pen' | 'eraser';
type StrokePoint = { x: number; y: number };
type Stroke = { points: StrokePoint[]; color: string; size: number; tool: Tool };
type Page = { strokes: Stroke[] };

const COLORS = ['#ffffff','#ff6b6b','#ffd93d','#6bcb77','#4d96ff','#c77dff','#ff9f43'];
const SIZES = [2,4,8,16,24];

export default function WhiteboardPage() {
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pages, setPages] = useState<Page[]>(() => {
    try { return JSON.parse(localStorage.getItem('wb-pages') || 'null') || [{ strokes: [] }]; }
    catch { return [{ strokes: [] }]; }
  });
  const [pageIdx, setPageIdx] = useState(0);
  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState('#ffffff');
  const [size, setSize] = useState(3);
  const [drawing, setDrawing] = useState(false);
  const currentStroke = useRef<StrokePoint[]>([]);
  const saveTimer = useRef<ReturnType<typeof setTimeout>>();

  const save = useCallback((pgs: Page[]) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try { localStorage.setItem('wb-pages', JSON.stringify(pgs)); } catch {}
    }, 500);
  }, []);

  const redraw = useCallback((pgs: Page[], idx: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    (pgs[idx]?.strokes || []).forEach(stroke => {
      if (stroke.points.length < 2) return;
      ctx.beginPath();
      ctx.strokeStyle = stroke.tool === 'eraser' ? '#111' : stroke.color;
      ctx.lineWidth = stroke.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      stroke.points.forEach(p => ctx.lineTo(p.x, p.y));
      ctx.stroke();
    });
  }, []);

  useEffect(() => { redraw(pages, pageIdx); }, [pages, pageIdx, redraw]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const rect = canvas.parentElement!.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = Math.max(rect.height, 400);
      redraw(pages, pageIdx);
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  const getPos = (e: React.TouchEvent | React.MouseEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    if ('touches' in e) {
      const t = e.touches[0];
      return { x: t.clientX - rect.left, y: t.clientY - rect.top };
    }
    return { x: (e as React.MouseEvent).clientX - rect.left, y: (e as React.MouseEvent).clientY - rect.top };
  };

  const startDraw = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    setDrawing(true);
    const pos = getPos(e);
    currentStroke.current = [pos];
    const ctx = canvasRef.current!.getContext('2d')!;
    ctx.beginPath();
    ctx.strokeStyle = tool === 'eraser' ? '#111' : color;
    ctx.lineWidth = tool === 'eraser' ? size * 4 : size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.moveTo(pos.x, pos.y);
  };

  const doDraw = (e: React.TouchEvent | React.MouseEvent) => {
    if (!drawing) return;
    e.preventDefault();
    const pos = getPos(e);
    currentStroke.current.push(pos);
    const ctx = canvasRef.current!.getContext('2d')!;
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  };

  const endDraw = () => {
    if (!drawing) return;
    setDrawing(false);
    if (currentStroke.current.length < 2) return;
    const newStroke: Stroke = { points: [...currentStroke.current], color, size: tool === 'eraser' ? size * 4 : size, tool };
    setPages(prev => {
      const updated = prev.map((p, i) => i === pageIdx ? { strokes: [...p.strokes, newStroke] } : p);
      save(updated);
      return updated;
    });
    currentStroke.current = [];
  };

  const undoLast = () => {
    setPages(prev => {
      const updated = prev.map((p, i) => i === pageIdx ? { strokes: p.strokes.slice(0, -1) } : p);
      save(updated);
      return updated;
    });
  };

  const clearPage = () => {
    setPages(prev => {
      const updated = prev.map((p, i) => i === pageIdx ? { strokes: [] } : p);
      save(updated);
      return updated;
    });
  };

  const addPage = () => {
    setPages(prev => { const n = [...prev, { strokes: [] }]; save(n); return n; });
    setPageIdx(pages.length);
  };

  const deletePage = () => {
    if (pages.length <= 1) { clearPage(); return; }
    setPages(prev => {
      const n = prev.filter((_, i) => i !== pageIdx);
      save(n);
      return n;
    });
    setPageIdx(i => Math.max(0, i - 1));
  };

  const exportPDF = async () => {
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: [canvasRef.current!.width, canvasRef.current!.height] });
    const origIdx = pageIdx;
    for (let i = 0; i < pages.length; i++) {
      redraw(pages, i);
      await new Promise(r => setTimeout(r, 100));
      const data = canvasRef.current!.toDataURL('image/png');
      if (i > 0) pdf.addPage();
      pdf.addImage(data, 'PNG', 0, 0, canvasRef.current!.width, canvasRef.current!.height);
    }
    redraw(pages, origIdx);
    pdf.save('hsc-whiteboard.pdf');
  };

  return (
    <div className="flex flex-col h-screen pb-16 md:pb-0">
      {/* Toolbar */}
      <div className="flex items-center gap-2 p-2 bg-surface border-b border-border flex-wrap shrink-0">
        <button onClick={() => navigate('/')} className="p-2 rounded-lg hover:bg-surface-alt">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <span className="font-bold text-sm hidden sm:inline">Whiteboard</span>

        {/* Tool */}
        <div className="flex gap-1 ml-1">
          <button onClick={() => setTool('pen')} className={cn("p-2 rounded-lg transition-colors", tool==='pen'?'bg-white text-black':'hover:bg-surface-alt')}>
            <Pencil className="h-4 w-4" />
          </button>
          <button onClick={() => setTool('eraser')} className={cn("p-2 rounded-lg transition-colors", tool==='eraser'?'bg-white text-black':'hover:bg-surface-alt')}>
            <Eraser className="h-4 w-4" />
          </button>
        </div>

        {/* Colors */}
        <div className="flex gap-1">
          {COLORS.map(c => (
            <button key={c} onClick={() => { setColor(c); setTool('pen'); }}
              className={cn("w-6 h-6 rounded-full border-2 transition-all", color===c&&tool==='pen'?'border-white scale-125':'border-transparent')}
              style={{ background: c }} />
          ))}
        </div>

        {/* Size */}
        <div className="flex items-center gap-1">
          <Minus className="h-3 w-3 text-secondary" />
          <input type="range" min="1" max="20" value={size} onChange={e=>setSize(+e.target.value)} className="w-16 accent-white" />
          <span className="text-xs text-secondary w-4">{size}</span>
        </div>

        {/* Pages */}
        <div className="flex gap-1 ml-auto">
          {pages.map((_, i) => (
            <button key={i} onClick={() => setPageIdx(i)}
              className={cn("w-7 h-7 rounded-lg text-xs font-bold transition-colors", i===pageIdx?'bg-white text-black':'bg-surface-alt hover:bg-surface text-white')}>
              {i+1}
            </button>
          ))}
          <button onClick={addPage} className="w-7 h-7 rounded-lg bg-surface-alt hover:bg-surface flex items-center justify-center">
            <Plus className="h-3 w-3" />
          </button>
        </div>

        {/* Actions */}
        <div className="flex gap-1">
          <button onClick={undoLast} className="px-2 py-1.5 rounded-lg bg-surface-alt hover:bg-surface text-xs">Undo</button>
          <button onClick={clearPage} className="p-2 rounded-lg hover:bg-red-500/20 text-red-400">
            <Trash2 className="h-4 w-4" />
          </button>
          <button onClick={deletePage} className="px-2 py-1.5 rounded-lg bg-surface-alt hover:bg-surface text-xs text-red-400">Del Page</button>
          <button onClick={exportPDF} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white text-black text-xs font-bold hover:bg-gray-200">
            <Download className="h-3 w-3" /> PDF
          </button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 overflow-hidden relative bg-[#111]" style={{ touchAction: 'none' }}>
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
          style={{ cursor: tool === 'eraser' ? 'cell' : 'crosshair' }}
          onMouseDown={startDraw} onMouseMove={doDraw} onMouseUp={endDraw} onMouseLeave={endDraw}
          onTouchStart={startDraw} onTouchMove={doDraw} onTouchEnd={endDraw}
        />
      </div>
    </div>
  );
}
