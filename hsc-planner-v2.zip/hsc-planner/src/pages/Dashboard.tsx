import CountdownHero from "@/components/dashboard/CountdownHero";
import FocusCard from "@/components/dashboard/FocusCard";
import QuoteBar from "@/components/dashboard/QuoteBar";
import SubjectProgress from "@/components/dashboard/SubjectProgress";
import Pomodoro from "@/components/dashboard/Pomodoro";
import Achievements from "@/components/dashboard/Achievements";
import { Link } from "react-router-dom";
import { GraduationCap, Calculator, PenLine, BookOpen, Search } from "lucide-react";

const QUICK_TOOLS = [
  { icon: GraduationCap, label: "Teachers", path: "/teachers", color: "text-yellow-400" },
  { icon: Search, label: "Search", path: "/search", color: "text-blue-400" },
  { icon: BookOpen, label: "Books", path: "/books", color: "text-green-400" },
  { icon: Calculator, label: "Calc", path: "/calculator", color: "text-purple-400" },
  { icon: PenLine, label: "Board", path: "/whiteboard", color: "text-pink-400" },
];

export default function Dashboard() {
  return (
    <div className="animate-in fade-in duration-500">
      <CountdownHero />
      <QuoteBar />

      {/* Quick Tool Shortcuts */}
      <div className="grid grid-cols-5 gap-2 mb-6">
        {QUICK_TOOLS.map(t => (
          <Link key={t.path} to={t.path}
            className="flex flex-col items-center gap-1.5 p-3 bg-surface border border-border rounded-xl hover:border-white/20 hover:bg-surface-alt transition-all active:scale-95">
            <t.icon className={`h-5 w-5 ${t.color}`} />
            <span className="text-[10px] text-secondary font-medium">{t.label}</span>
          </Link>
        ))}
      </div>

      <Achievements />
      <FocusCard />
      <SubjectProgress />
      <Pomodoro />
    </div>
  );
}

