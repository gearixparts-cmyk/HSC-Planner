import { useState, useCallback } from 'react';
import { ChevronLeft, Delete } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

type Mode = 'DEG' | 'RAD';
type CalcState = { expr: string; result: string; justCalc: boolean };

const initState: CalcState = { expr: '', result: '0', justCalc: false };

export default function CalculatorPage() {
  const navigate = useNavigate();
  const [state, setState] = useState<CalcState>(initState);
  const [mode, setMode] = useState<Mode>('DEG');
  const [shiftOn, setShiftOn] = useState(false);
  const [alphaOn, setAlphaOn] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  const deg2rad = (x: number) => mode === 'DEG' ? x * Math.PI / 180 : x;
  const rad2deg = (x: number) => mode === 'DEG' ? x * 180 / Math.PI : x;

  const safeEval = useCallback((expr: string): string => {
    try {
      let e = expr
        .replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, `(${Math.PI})`)
        .replace(/e(?!x)/g, `(${Math.E})`)
        .replace(/sin⁻¹\(/g, `__asin(`)
        .replace(/cos⁻¹\(/g, `__acos(`)
        .replace(/tan⁻¹\(/g, `__atan(`)
        .replace(/sin\(/g, `__sin(`)
        .replace(/cos\(/g, `__sin(`)  
        .replace(/tan\(/g, `__tan(`)
        .replace(/log\(/g, `Math.log10(`)
        .replace(/ln\(/g, `Math.log(`)
        .replace(/√\(/g, `Math.sqrt(`)
        .replace(/∛\(/g, `Math.cbrt(`)
        .replace(/\^/g, `**`)
        .replace(/__sin\(/g, `(Math.sin(${mode==='DEG'?'(Math.PI/180)*':''}`)
        .replace(/__asin\(/g, `(${mode==='DEG'?'(180/Math.PI)*':''}Math.asin(`)
        .replace(/__acos\(/g, `(${mode==='DEG'?'(180/Math.PI)*':''}Math.acos(`)
        .replace(/__atan\(/g, `(${mode==='DEG'?'(180/Math.PI)*':''}Math.atan(`);
      // Fix tan
      e = e.replace(/\(Math\.sin\(/g,'(Math.sin(');
      const fixedExpr = expr
        .replace(/×/g,'*').replace(/÷/g,'/').replace(/π/g,`${Math.PI}`)
        .replace(/e(?!x)/g,`${Math.E}`).replace(/\^/g,'**');
      
      // Use a safe expression evaluator
      const fn = new Function('Math', `"use strict"; return (${buildSafeExpr(expr, mode === 'DEG')});`);
      const result = fn(Math);
      if (!isFinite(result)) return 'Error';
      const r = parseFloat(result.toPrecision(12));
      return String(r);
    } catch {
      return 'Error';
    }
  }, [mode]);

  const append = (val: string) => {
    setState(s => {
      const base = s.justCalc && !isNaN(Number(val)) ? '' : s.justCalc ? s.expr : s.expr;
      return { expr: (s.justCalc && !isNaN(Number(val)) ? '' : s.expr) + val, result: s.result, justCalc: false };
    });
    setShiftOn(false); setAlphaOn(false);
  };

  const calculate = () => {
    if (!state.expr) return;
    const r = safeEval(state.expr);
    setHistory(h => [`${state.expr} = ${r}`, ...h.slice(0,9)]);
    setState({ expr: state.expr, result: r, justCalc: true });
  };

  const clear = () => setState(initState);
  const backspace = () => setState(s => ({ ...s, expr: s.expr.slice(0,-1), justCalc: false }));
  const ans = () => append(state.result === '0' ? '' : state.result);

  const display = state.justCalc ? state.result : (state.expr || '0');

  type Btn = { label: string; val?: string; fn?: ()=>void; cls?: string; wide?: boolean };
  
  const rows: Btn[][] = [
    [
      { label: shiftOn?'SHIFT':'SHIFT', fn:()=>setShiftOn(s=>!s), cls: shiftOn?'bg-yellow-500 text-black':'btn-func' },
      { label: alphaOn?'ALPHA':'ALPHA', fn:()=>setAlphaOn(s=>!s), cls: alphaOn?'bg-green-500 text-black':'btn-func' },
      { label: mode, fn:()=>setMode(m=>m==='DEG'?'RAD':'DEG'), cls:'btn-func' },
      { label:'CALC', fn:()=>{}, cls:'btn-func' },
      { label:'∫dx', fn:()=>{}, cls:'btn-func' },
    ],
    [
      { label: shiftOn?'sin⁻¹':'sin', val: shiftOn?'sin⁻¹(':'sin(' },
      { label: shiftOn?'cos⁻¹':'cos', val: shiftOn?'cos⁻¹(':'cos(' },
      { label: shiftOn?'tan⁻¹':'tan', val: shiftOn?'tan⁻¹(':'tan(' },
      { label:'xⁿ', val:'^' },
      { label:'log', val:'log(' },
      { label:'ln', val:'ln(' },
    ],
    [
      { label:'x²', val:'^2' },
      { label:'x³', val:'^3' },
      { label:'√(', val:'√(' },
      { label:'∛(', val:'∛(' },
      { label:'%', val:'%' },
      { label:'π', val:'π' },
    ],
    [
      { label:'(', val:'(' },
      { label:')', val:')' },
      { label:'M+', fn:()=>{localStorage.setItem('calc-mem',(parseFloat(localStorage.getItem('calc-mem')||'0')+(parseFloat(state.result)||0)).toString())}, cls:'btn-func' },
      { label:'MR', fn:()=>append(localStorage.getItem('calc-mem')||'0'), cls:'btn-func' },
      { label:'MC', fn:()=>localStorage.setItem('calc-mem','0'), cls:'btn-func' },
      { label:'e', val:'e' },
    ],
    [
      { label:'7', val:'7', cls:'btn-num' },
      { label:'8', val:'8', cls:'btn-num' },
      { label:'9', val:'9', cls:'btn-num' },
      { label:'DEL', fn:backspace, cls:'btn-op' },
      { label:'AC', fn:clear, cls:'bg-red-600 hover:bg-red-500 text-white font-bold' },
    ],
    [
      { label:'4', val:'4', cls:'btn-num' },
      { label:'5', val:'5', cls:'btn-num' },
      { label:'6', val:'6', cls:'btn-num' },
      { label:'×', val:'×', cls:'btn-op' },
      { label:'÷', val:'÷', cls:'btn-op' },
    ],
    [
      { label:'1', val:'1', cls:'btn-num' },
      { label:'2', val:'2', cls:'btn-num' },
      { label:'3', val:'3', cls:'btn-num' },
      { label:'+', val:'+', cls:'btn-op' },
      { label:'−', val:'-', cls:'btn-op' },
    ],
    [
      { label:'0', val:'0', cls:'btn-num' },
      { label:'.', val:'.', cls:'btn-num' },
      { label:'×10ˣ', val:'*10^', cls:'btn-num' },
      { label:'Ans', fn:ans, cls:'btn-func' },
      { label:'=', fn:calculate, cls:'bg-white text-black hover:bg-gray-200 font-bold text-xl col-span-1' },
    ],
  ];

  return (
    <div className="pb-24 animate-in fade-in duration-300 max-w-sm mx-auto">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate('/')} className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-xl font-bold">Scientific Calculator</h1>
          <p className="text-secondary text-xs">Casio fx-991EX style</p>
        </div>
      </div>

      {/* Display */}
      <div className="bg-[#1a1f2e] border border-border rounded-xl p-4 mb-3">
        <div className="text-xs text-secondary font-mono mb-1 min-h-[16px] truncate">{state.expr || ' '}</div>
        <div className={cn("font-mono text-right break-all leading-tight", display.length > 15 ? 'text-lg' : 'text-3xl', state.result === 'Error' && 'text-red-400')}>
          {display}
        </div>
        <div className="flex justify-between mt-2 text-[10px] text-secondary">
          <span>{mode}</span>
          <span>{shiftOn && <span className="text-yellow-400 mr-1">SHIFT</span>}{alphaOn && <span className="text-green-400">ALPHA</span>}</span>
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="mb-3 bg-surface border border-border rounded-xl p-3 max-h-20 overflow-y-auto">
          {history.map((h, i) => <div key={i} className="text-xs text-secondary font-mono truncate">{h}</div>)}
        </div>
      )}

      {/* Buttons */}
      <div className="space-y-1.5">
        {rows.map((row, ri) => (
          <div key={ri} className="grid gap-1.5" style={{gridTemplateColumns:`repeat(${row.length},1fr)`}}>
            {row.map((btn, bi) => (
              <button
                key={bi}
                onClick={() => btn.fn ? btn.fn() : btn.val && append(btn.val)}
                className={cn(
                  "h-12 rounded-xl text-sm font-medium transition-all active:scale-95 select-none",
                  btn.cls || 'bg-surface-alt border border-border hover:bg-surface text-white',
                  btn.label === '=' && 'h-12',
                )}
              >
                {btn.label}
              </button>
            ))}
          </div>
        ))}
      </div>

      <style>{`
        .btn-num { background: #1e2330; border: 1px solid #333; color: white; }
        .btn-num:hover { background: #252b3b; }
        .btn-op { background: #2a2040; border: 1px solid #444; color: #a78bfa; font-weight: bold; }
        .btn-op:hover { background: #332550; }
        .btn-func { background: #1a2020; border: 1px solid #2a3030; color: #6ee7b7; font-size: 11px; }
        .btn-func:hover { background: #1e2a2a; }
      `}</style>
    </div>
  );
}

function buildSafeExpr(expr: string, deg: boolean): string {
  const d = deg ? '(Math.PI/180)*' : '';
  const rd = deg ? '(180/Math.PI)*' : '';
  return expr
    .replace(/×/g,'*').replace(/÷/g,'/').replace(/π/g,`${Math.PI}`).replace(/e(?!\d)/g,`${Math.E}`)
    .replace(/sin⁻¹\(/g,`(${rd}Math.asin(`).replace(/cos⁻¹\(/g,`(${rd}Math.acos(`).replace(/tan⁻¹\(/g,`(${rd}Math.atan(`)
    .replace(/sin\(/g,`Math.sin(${d}`).replace(/cos\(/g,`Math.cos(${d}`).replace(/tan\(/g,`Math.tan(${d}`)
    .replace(/log\(/g,`Math.log10(`).replace(/ln\(/g,`Math.log(`)
    .replace(/√\(/g,`Math.sqrt(`).replace(/∛\(/g,`Math.cbrt(`).replace(/\^/g,`**`)
    .replace(/%/g,`/100`);
}
