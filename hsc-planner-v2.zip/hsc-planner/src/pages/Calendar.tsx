import { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, addMonths, subMonths, isToday } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function Calendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const days = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth),
  });

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  // Helper to check if tasks exist/completed for a day
  const getDayStatus = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const tasksStr = localStorage.getItem(`tasks-${dateStr}`);
    
    if (!tasksStr) return 'empty';
    
    const tasks = JSON.parse(tasksStr);
    if (tasks.length === 0) return 'empty';
    
    const allCompleted = tasks.every((t: any) => t.completed);
    return allCompleted ? 'completed' : 'missed';
  };

  return (
    <div className="pb-24 animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-8">
        <button onClick={prevMonth} className="p-2 hover:bg-surface-alt rounded-full transition-colors">
          <ChevronLeft className="h-5 w-5 text-white" />
        </button>
        <h1 className="text-xl font-bold text-white">
          {format(currentMonth, 'MMMM yyyy')}
        </h1>
        <button onClick={nextMonth} className="p-2 hover:bg-surface-alt rounded-full transition-colors">
          <ChevronRight className="h-5 w-5 text-white" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div key={day} className="text-center text-xs text-secondary uppercase tracking-wider py-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {/* Padding for start of month */}
        {Array.from({ length: startOfMonth(currentMonth).getDay() }).map((_, i) => (
          <div key={`pad-${i}`} className="aspect-square" />
        ))}

        {days.map((day) => {
          const status = getDayStatus(day);
          return (
            <Link
              key={day.toString()}
              to={`/planner/${format(day, 'yyyy-MM-dd')}`}
              className={cn(
                "aspect-square flex flex-col items-center justify-center rounded-lg border border-transparent hover:bg-surface-alt transition-all relative",
                isToday(day) && "border-white bg-surface",
                !isSameMonth(day, currentMonth) && "opacity-30",
                status === 'completed' && "bg-green-900/20 border-green-900/50",
                status === 'missed' && "bg-red-900/20 border-red-900/50"
              )}
            >
              <span className={cn("text-sm font-medium", isToday(day) ? "text-white" : "text-secondary")}>
                {format(day, 'd')}
              </span>
              
              {status === 'completed' && (
                <div className="w-1 h-1 bg-green-500 rounded-full mt-1" />
              )}
              {status === 'missed' && (
                <div className="w-1 h-1 bg-red-500 rounded-full mt-1" />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
