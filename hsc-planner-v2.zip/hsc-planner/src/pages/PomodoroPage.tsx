import Pomodoro from "@/components/dashboard/Pomodoro";

export default function PomodoroPage() {
  return (
    <div className="pb-24 animate-in fade-in duration-500 flex flex-col items-center justify-center min-h-[80vh]">
      <h1 className="text-2xl font-bold mb-8">Focus Timer</h1>
      <div className="w-full max-w-md">
        <Pomodoro isStatic={true} />
      </div>
    </div>
  );
}
