import { useState, useMemo } from 'react';
import { Search, ExternalLink, Plus, Trash2, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const SUBJECTS = ['Math', 'Physics', 'Chemistry', 'Biology', 'ICT', 'English', 'Bangla'];

const TEACHERS_BY_SUBJECT: Record<string, string[]> = {
  Math: ['Math & Science Nerds', 'Kamrul Islam', 'Abhi Datta Tushar'],
  Physics: ['Physics Saviour', 'Apurbo', 'Physics Vaiya'],
  Chemistry: ['AloronXYZ', 'AR Vaia (Bondhi Pathshala)'],
  Biology: ['Dr. Abrar Hamim', 'Hasnat Shuvro'],
  ICT: ['Math & Science Nerds', 'Fahad Tutorials (Sany Sir)', 'HSC Crackers'],
  English: ['English Moja'],
  Bangla: ['Obelar Bangla', 'বাংলা বিদ্যা', 'Nahid24', 'Udvash'],
};

const TEACHER_URLS: Record<string, string> = {
  'Math & Science Nerds': 'https://www.youtube.com/@MathScienceNerds/playlists',
  'Kamrul Islam': 'https://www.youtube.com/@kamrulislam/playlists',
  'Abhi Datta Tushar': 'https://www.youtube.com/@abhidattatushar156/playlists',
  'Physics Saviour': 'https://www.youtube.com/@ThePhysicsSaviour',
  'Apurbo': 'https://www.youtube.com/@apurbophysics/playlists',
  'Physics Vaiya': 'https://www.youtube.com/@PHYSICSvaiya05321/playlists',
  'AloronXYZ': 'https://www.youtube.com/@aloronxyz/playlists',
  'AR Vaia (Bondhi Pathshala)': 'https://www.youtube.com/playlist?list=PLBIUjjCw0wBIkkofSaKgm5PszW58e4089',
  'Dr. Abrar Hamim': 'https://www.youtube.com/@Master_biology/playlists',
  'Hasnat Shuvro': 'https://www.youtube.com/@HasnatShuvro/playlists',
  'Fahad Tutorials (Sany Sir)': 'https://www.youtube.com/playlist?list=PLh2EsjwYJx7u1CNOx2Hf6D3Ave676BopE',
  'HSC Crackers': 'https://www.youtube.com/playlist?list=PLersUpanCgbMHpp44hjCZy4tgdKFDvtJQ',
  'English Moja': 'https://www.youtube.com/@EnglishMoja/playlists',
  'Obelar Bangla': 'https://www.youtube.com/@ObelarBangla2021/playlists',
  'বাংলা বিদ্যা': 'https://www.youtube.com/playlist?list=PLivTO2NHEJKYNY1gZ1FrY23Zw2OOaCwNr',
  'Nahid24': 'https://www.youtube.com/@Nahid24/playlists',
  'Udvash': 'https://www.youtube.com/playlist?list=PL3fBB5-oEa1ymekXzL_jqGurBD-KcZVcy',
};

type ContentType = 'Video' | 'Playlist' | 'Oneshot' | 'MCQ' | '';
interface UserEntry { id: string; subject: string; paper: string; teacher: string; topic: string; type: string; url: string; }

function getUserEntries(): UserEntry[] {
  try { return JSON.parse(localStorage.getItem('search-user-entries') || '[]'); } catch { return []; }
}
function saveUserEntries(entries: UserEntry[]) {
  localStorage.setItem('search-user-entries', JSON.stringify(entries));
}

export default function SubjectSearch() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [subject, setSubject] = useState('');
  const [paper, setPaper] = useState('');
  const [teacher, setTeacher] = useState('');
  const [type, setType] = useState<ContentType>('');
  const [userEntries, setUserEntries] = useState<UserEntry[]>(getUserEntries);
  const [showAdd, setShowAdd] = useState(false);
  const [newEntry, setNewEntry] = useState<Partial<UserEntry>>({});

  const teachers = subject ? TEACHERS_BY_SUBJECT[subject] || [] : [];

  // Build search URL for YouTube
  const buildSearchUrl = () => {
    const parts = ['HSC'];
    if (subject) parts.push(subject);
    if (paper) parts.push(paper);
    if (teacher) parts.push(teacher);
    if (query) parts.push(query);
    if (type) parts.push(type);
    return `https://www.youtube.com/results?search_query=${encodeURIComponent(parts.join(' '))}`;
  };

  // Direct teacher URL if selected
  const directUrl = teacher && TEACHER_URLS[teacher] ? TEACHER_URLS[teacher] : null;

  const filteredUserEntries = useMemo(() => {
    return userEntries.filter(e => {
      if (subject && e.subject && e.subject !== subject) return false;
      if (paper && e.paper && e.paper !== paper) return false;
      if (teacher && e.teacher && !e.teacher.toLowerCase().includes(teacher.toLowerCase())) return false;
      if (query && !e.topic.toLowerCase().includes(query.toLowerCase()) && !e.teacher.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [userEntries, subject, paper, teacher, query]);

  const addEntry = () => {
    if (!newEntry.topic && !newEntry.url) { toast.error('Add at least a topic or URL'); return; }
    const entry: UserEntry = {
      id: crypto.randomUUID(),
      subject: newEntry.subject || subject || '',
      paper: newEntry.paper || paper || '',
      teacher: newEntry.teacher || teacher || '',
      topic: newEntry.topic || '',
      type: newEntry.type || type || '',
      url: newEntry.url || buildSearchUrl(),
    };
    const updated = [entry, ...userEntries];
    setUserEntries(updated);
    saveUserEntries(updated);
    setNewEntry({});
    setShowAdd(false);
    toast.success('Added to your search entries');
  };

  const deleteEntry = (id: string) => {
    const updated = userEntries.filter(e => e.id !== id);
    setUserEntries(updated);
    saveUserEntries(updated);
  };

  const hasFilters = subject || paper || teacher || query || type;

  return (
    <div className="pb-24 animate-in fade-in duration-300">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/subjects')} className="p-2 rounded-xl border border-border hover:bg-surface-alt transition-colors">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Search className="h-5 w-5 text-blue-400" /> Subject Search</h1>
          <p className="text-secondary text-xs">Find videos, playlists, MCQs by subject, teacher, topic</p>
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-3 bg-surface border border-border rounded-xl p-4 mb-4">
        {/* Search query */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-secondary" />
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Topic name, chapter, keyword..."
            className="w-full bg-surface-alt border border-border rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-white/40 transition-colors" />
        </div>

        {/* Subject + Paper */}
        <div className="grid grid-cols-2 gap-3">
          <select value={subject} onChange={e => { setSubject(e.target.value); setTeacher(''); }}
            className="bg-surface-alt border border-border rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-white/40 transition-colors">
            <option value="">All Subjects</option>
            {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <select value={paper} onChange={e => setPaper(e.target.value)}
            className="bg-surface-alt border border-border rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-white/40 transition-colors">
            <option value="">Any Paper</option>
            <option value="1st Paper">1st Paper</option>
            <option value="2nd Paper">2nd Paper</option>
          </select>
        </div>

        {/* Teacher + Type */}
        <div className="grid grid-cols-2 gap-3">
          <select value={teacher} onChange={e => setTeacher(e.target.value)}
            className="bg-surface-alt border border-border rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-white/40 transition-colors">
            <option value="">Any Teacher</option>
            {(subject ? teachers : Object.keys(TEACHER_URLS)).map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <select value={type} onChange={e => setType(e.target.value as ContentType)}
            className="bg-surface-alt border border-border rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-white/40 transition-colors">
            <option value="">Any Type</option>
            <option value="Video">Video</option>
            <option value="Playlist">Playlist</option>
            <option value="Oneshot">Oneshot</option>
            <option value="MCQ">MCQ</option>
          </select>
        </div>

        {/* Search button */}
        <a href={buildSearchUrl()} target="_blank" rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2 bg-white text-black font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors">
          <Search className="h-4 w-4" />
          Search on YouTube
        </a>

        {/* Direct teacher link */}
        {directUrl && (
          <a href={directUrl} target="_blank" rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 border border-border bg-surface-alt py-2.5 rounded-xl text-sm hover:border-white/20 transition-colors">
            <ExternalLink className="h-4 w-4 text-blue-400" />
            Go to {teacher}'s Playlists
          </a>
        )}
      </div>

      {/* User Entries */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-sm text-secondary uppercase tracking-wider">Your Saved Links</h3>
          <button onClick={() => setShowAdd(!showAdd)}
            className="flex items-center gap-1 text-xs bg-surface-alt border border-border px-3 py-1.5 rounded-lg hover:border-white/20 transition-colors">
            <Plus className="h-3 w-3" /> Add Link
          </button>
        </div>

        {showAdd && (
          <div className="bg-surface border border-border rounded-xl p-4 mb-3 space-y-3 animate-in fade-in duration-200">
            <input placeholder="Topic / Title" value={newEntry.topic || ''} onChange={e => setNewEntry(n => ({...n, topic: e.target.value}))}
              className="w-full bg-surface-alt border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-white/40" />
            <input placeholder="YouTube URL" value={newEntry.url || ''} onChange={e => setNewEntry(n => ({...n, url: e.target.value}))}
              className="w-full bg-surface-alt border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-white/40" />
            <div className="grid grid-cols-2 gap-2">
              <input placeholder="Teacher name" value={newEntry.teacher || ''} onChange={e => setNewEntry(n => ({...n, teacher: e.target.value}))}
                className="bg-surface-alt border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-white/40" />
              <input placeholder="Type (MCQ/Playlist...)" value={newEntry.type || ''} onChange={e => setNewEntry(n => ({...n, type: e.target.value}))}
                className="bg-surface-alt border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-white/40" />
            </div>
            <div className="flex gap-2">
              <button onClick={addEntry} className="flex-1 bg-white text-black font-bold py-2.5 rounded-xl text-sm hover:bg-gray-200 transition-colors">Save</button>
              <button onClick={() => setShowAdd(false)} className="px-4 py-2.5 border border-border rounded-xl text-sm hover:bg-surface-alt transition-colors">Cancel</button>
            </div>
          </div>
        )}

        {filteredUserEntries.length > 0 ? (
          <div className="space-y-2">
            {filteredUserEntries.map(entry => (
              <div key={entry.id} className="flex items-center gap-3 p-3 bg-surface border border-border rounded-xl">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{entry.topic || 'My Link'}</div>
                  <div className="text-[11px] text-secondary mt-0.5">
                    {[entry.subject, entry.paper, entry.teacher, entry.type].filter(Boolean).join(' • ')}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <a href={entry.url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 bg-white text-black px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-gray-200">
                    Open <ExternalLink className="h-3 w-3" />
                  </a>
                  <button onClick={() => deleteEntry(entry.id)} className="p-1.5 hover:text-red-400 transition-colors">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          userEntries.length === 0 && (
            <p className="text-sm text-secondary text-center py-4">No saved links yet. Add your own YouTube links above.</p>
          )
        )}
      </div>
    </div>
  );
}
