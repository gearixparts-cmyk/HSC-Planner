import { useState, useEffect, FormEvent } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Youtube } from 'lucide-react';
import { INITIAL_SUBJECTS } from '@/lib/data';
import { cn } from '@/lib/utils';

interface Chapter {
  id: string;
  name: string;
  completed: boolean;
}

export default function SubjectDetail() {
  const { id } = useParams();
  const subject = INITIAL_SUBJECTS.find(s => s.id === id);
  
  const [chapters, setChapters] = useState<Chapter[]>(() => {
    const saved = localStorage.getItem(`chapters-${id}`);
    return saved ? JSON.parse(saved) : [];
  });
  const [newChapter, setNewChapter] = useState('');

  useEffect(() => {
    localStorage.setItem(`chapters-${id}`, JSON.stringify(chapters));
  }, [chapters, id]);

  if (!subject) return <div>Subject not found</div>;

  const progress = chapters.length > 0 
    ? Math.round((chapters.filter(c => c.completed).length / chapters.length) * 100) 
    : 0;

  const addChapter = (e: FormEvent) => {
    e.preventDefault();
    if (!newChapter.trim()) return;
    setChapters([...chapters, { id: crypto.randomUUID(), name: newChapter, completed: false }]);
    setNewChapter('');
  };

  const toggleChapter = (chapterId: string) => {
    setChapters(chapters.map(c => c.id === chapterId ? { ...c, completed: !c.completed } : c));
  };

  const deleteChapter = (chapterId: string) => {
    setChapters(chapters.filter(c => c.id !== chapterId));
  };

  const getYoutubeLink = (chapterName: string) => {
    const query = `hsc ${subject.name} ${subject.paper} ${chapterName} ${subject.channel}`;
    return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
  };

  return (
    <div className="pb-24 animate-in fade-in duration-300">
      <Link to="/subjects" className="inline-flex items-center text-secondary hover:text-white mb-6 transition-colors">
        <ArrowLeft className="h-4 w-4 mr-2" /> Back to Subjects
      </Link>

      <div className="bg-surface border border-border rounded-xl p-6 mb-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">{subject.name}</h1>
            <p className="text-secondary">{subject.paper}</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-white">{progress}%</div>
            <div className="text-xs text-secondary">Completed</div>
          </div>
        </div>

        <div className="h-1 w-full bg-surface-alt rounded-full overflow-hidden">
          <div className="h-full bg-white transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-bold mb-4">Chapters</h3>
        <form onSubmit={addChapter} className="flex gap-2 mb-4">
          <input
            type="text"
            value={newChapter}
            onChange={(e) => setNewChapter(e.target.value)}
            placeholder="Add chapter name..."
            className="flex-1 bg-surface-alt border border-border rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-white transition-colors"
          />
          <button type="submit" className="bg-white text-black rounded-lg px-4 py-2 hover:bg-gray-200">
            <Plus className="h-5 w-5" />
          </button>
        </form>

        <div className="space-y-2">
          {chapters.length === 0 && (
            <p className="text-center text-muted text-sm py-8">No chapters added yet.</p>
          )}
          {chapters.map((chapter) => (
            <div key={chapter.id} className="group bg-surface border border-border rounded-lg p-4 flex items-center gap-3 hover:border-muted transition-colors">
              <input
                type="checkbox"
                checked={chapter.completed}
                onChange={() => toggleChapter(chapter.id)}
                className="h-5 w-5 rounded border-secondary bg-transparent checked:bg-white checked:border-white transition-all cursor-pointer accent-white"
              />
              <span className={cn("flex-1 font-medium", chapter.completed && "line-through text-muted")}>
                {chapter.name}
              </span>
              
              <a 
                href={getYoutubeLink(chapter.name)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted hover:text-[#FF0000] transition-colors p-2"
                title="Search on YouTube"
              >
                <Youtube className="h-5 w-5" />
              </a>
              
              <button 
                onClick={() => deleteChapter(chapter.id)}
                className="text-muted hover:text-danger opacity-0 group-hover:opacity-100 transition-all p-2"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
      
      {subject.name === 'ICT' && (
        <div className="mt-8 p-4 bg-surface-alt rounded-lg border border-border">
          <h4 className="font-bold mb-2 flex items-center gap-2">
            <Youtube className="h-4 w-4 text-[#FF0000]" /> 
            Recommended Playlist
          </h4>
          <a 
            href="https://www.youtube.com/playlist?list=PLi5fEbOt0If7Yo4Vt-G0q_byIKVzoFdxa"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-secondary hover:text-white underline underline-offset-4"
          >
            Watch ICT Playlist by Fahad Tutorial / Sany Sir
          </a>
        </div>
      )}
    </div>
  );
}
