import { useState, useEffect } from 'react';
import { Download } from 'lucide-react';
import { getSubjectProgress, SubjectProgressData } from '@/lib/progress';
import jsPDF from 'jspdf';
import { subDays, format } from 'date-fns';

export default function Weekly() {
  const [isExporting, setIsExporting] = useState(false);
  const [stats, setStats] = useState({
    pomodoro: 0,
    tasks: 0,
    productivity: 0,
    missed: 0
  });
  const [progressData, setProgressData] = useState<SubjectProgressData[]>([]);

  useEffect(() => {
    // Calculate stats for the last 7 days
    let totalPomodoro = 0;
    let totalTasks = 0;
    let totalProductivity = 0;
    let productivityCount = 0;
    let missedDays = 0;

    for (let i = 0; i < 7; i++) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');

      // Pomodoro
      const pomodoroCount = localStorage.getItem(`pomodoro-${dateStr}`);
      if (pomodoroCount) {
        const parsed = parseInt(pomodoroCount);
        if (!isNaN(parsed)) totalPomodoro += parsed;
      }

      // Tasks
      const tasksStr = localStorage.getItem(`tasks-${dateStr}`);
      if (tasksStr) {
        try {
          const tasks = JSON.parse(tasksStr);
          if (Array.isArray(tasks)) {
            const completed = tasks.filter((t: any) => t.completed).length;
            totalTasks += completed;
            
            // Check for missed days (if tasks existed but none completed)
            if (tasks.length > 0 && completed === 0) {
              missedDays++;
            }
          }
        } catch (e) {
          console.error(`Failed to parse tasks for ${dateStr}`, e);
        }
      }

      // Productivity
      const journalStr = localStorage.getItem(`journal-${dateStr}`);
      if (journalStr) {
        try {
          const journal = JSON.parse(journalStr);
          if (journal && typeof journal.rating === 'number' && journal.rating > 0) {
            totalProductivity += journal.rating;
            productivityCount++;
          }
        } catch (e) {
          console.error(`Failed to parse journal for ${dateStr}`, e);
        }
      }
    }

    setStats({
      pomodoro: totalPomodoro,
      tasks: totalTasks,
      productivity: productivityCount > 0 ? Number((totalProductivity / productivityCount).toFixed(1)) : 0,
      missed: missedDays
    });

    // Load subject progress
    const updateProgress = () => {
      setProgressData(getSubjectProgress());
    };

    updateProgress();
    window.addEventListener('storage', updateProgress);
    window.addEventListener('local-storage-update', updateProgress);

    return () => {
      window.removeEventListener('storage', updateProgress);
      window.removeEventListener('local-storage-update', updateProgress);
    };
  }, []);

  const handleExport = () => {
    setIsExporting(true);
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("HSC Planner - Weekly Report", 20, 20);
    doc.setFontSize(12);
    doc.text(`Week of ${new Date().toLocaleDateString()}`, 20, 30);
    
    doc.text(`Pomodoro Sessions: ${stats.pomodoro}`, 20, 50);
    doc.text(`Tasks Completed: ${stats.tasks}`, 20, 60);
    doc.text(`Avg Productivity: ${stats.productivity}/5`, 20, 70);
    
    doc.save("weekly-report.pdf");
    setIsExporting(false);
  };

  return (
    <div className="pb-24 animate-in fade-in duration-500">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">All Data</h1>
        <button 
          onClick={handleExport}
          disabled={isExporting}
          className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
        >
          <Download className="h-4 w-4" />
          {isExporting ? "Exporting..." : "Export PDF"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-3xl font-bold text-white mb-1">{stats.pomodoro}</div>
          <div className="text-xs text-secondary uppercase tracking-wider">Pomodoro Sessions</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-3xl font-bold text-white mb-1">{stats.tasks}</div>
          <div className="text-xs text-secondary uppercase tracking-wider">Tasks Done</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-3xl font-bold text-white mb-1">{stats.productivity}</div>
          <div className="text-xs text-secondary uppercase tracking-wider">Avg Productivity</div>
        </div>
        <div className="bg-surface border border-border rounded-xl p-4">
          <div className="text-3xl font-bold text-white mb-1">{stats.missed}</div>
          <div className="text-xs text-secondary uppercase tracking-wider">Missed Days</div>
        </div>
      </div>

      <h2 className="text-lg font-bold mb-4">Subject Progress</h2>
      <div className="space-y-4">
        {progressData.map((subject) => (
          <div key={subject.id} className="bg-surface border border-border rounded-xl p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-white">{subject.name}</span>
              <span className="text-sm font-mono text-secondary">{subject.percentage}%</span>
            </div>
            <div className="h-1 w-full bg-surface-alt rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-500" 
                style={{ width: `${subject.percentage}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
