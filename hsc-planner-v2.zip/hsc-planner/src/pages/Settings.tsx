import { useState, useEffect, ChangeEvent } from 'react';
import { 
  Bell, 
  FileText, 
  Moon, 
  Sun, 
  User, 
  Trash2, 
  Download, 
  LogOut, 
  Info, 
  ShieldCheck,
  ChevronRight,
  GraduationCap
} from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useBatch } from '@/hooks/useBatch';
import { requestNotificationPermission, NOTIFICATION_KEY, REMINDER_TIME_KEY } from '@/lib/notifications';

export default function Settings() {
  const [importing, setImporting] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const { batchYear, setBatch } = useBatch();
  const [reminderTime, setReminderTime] = useState(localStorage.getItem(REMINDER_TIME_KEY) || '19:00');
  
  // Profile State (Mock)
  const [profile, setProfile] = useState({
    name: "Student",
    email: "student@example.com"
  });

  useEffect(() => {
    // Sync dark mode with document
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleChangeBatch = () => {
    const newBatch = prompt("Enter your HSC Batch Year (e.g., 2026, 2027):", batchYear?.toString());
    if (newBatch) {
      const year = parseInt(newBatch);
      if (!isNaN(year) && year >= 2024 && year <= 2030) {
        if (confirm(`Are you sure you want to switch to HSC ${year}? This will update your exam countdown.`)) {
          setBatch(year);
          toast.success(`Batch updated to HSC ${year}`);
        }
      } else {
        toast.error("Invalid year. Please enter a year between 2024 and 2030.");
      }
    }
  };

  const handleNotificationToggle = () => {
    if (!notifications) {
      requestNotificationPermission();
      setNotifications(true);
    } else {
      localStorage.setItem(NOTIFICATION_KEY, 'false');
      setNotifications(false);
      toast.success("Notifications disabled");
    }
  };

  const handleTimeChange = (e: ChangeEvent<HTMLInputElement>) => {
    const time = e.target.value;
    setReminderTime(time);
    localStorage.setItem(REMINDER_TIME_KEY, time);
    toast.success(`Reminder set for ${time}`);
  };

  const handleImportRoutine = () => {
    if (confirm("This will add Udvash routine tasks to your planner. Continue?")) {
      setImporting(true);
      
      setTimeout(() => {
        const mockTasks = [
          { date: '2026-03-02', text: '[Udvash] Physics 1st: Vector' },
          { date: '2026-03-03', text: '[Udvash] Chem 1st: Qualitative Chemistry' },
          { date: '2026-03-04', text: '[Udvash] Math 1st: Matrix' },
        ];

        mockTasks.forEach(task => {
          const key = `tasks-${task.date}`;
          const existing = localStorage.getItem(key);
          const tasks = existing ? JSON.parse(existing) : [];
          tasks.push({
            id: crypto.randomUUID(),
            text: task.text,
            completed: false,
            date: task.date
          });
          localStorage.setItem(key, JSON.stringify(tasks));
        });

        setImporting(false);
        toast.success("Udvash Routine Imported Successfully");
        window.dispatchEvent(new Event('storage'));
      }, 1500);
    }
  };

  const [clearStep, setClearStep] = useState(0);

  const handleResetData = () => {
    if (clearStep === 0) {
      setClearStep(1);
    } else if (clearStep === 1) {
      setClearStep(2);
    } else {
      localStorage.clear();
      toast.success("All data cleared.");
      setTimeout(() => window.location.reload(), 800);
    }
  };

  const handleExportData = () => {
    const data: Record<string, any> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        data[key] = localStorage.getItem(key);
      }
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hsc26-planner-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast.success("Data exported successfully");
  };

  const handleLogout = () => {
    toast.success("Logged out successfully");
    // In a real app, this would clear auth tokens
  };

  return (
    <div className="pb-24 animate-in fade-in duration-500 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-secondary text-sm mt-1">Manage your preferences and data.</p>
      </div>

      {/* Profile Section */}
      <section className="bg-surface border border-border rounded-xl overflow-hidden">
        <div className="p-6 border-b border-border flex items-center gap-4">
          <div className="h-16 w-16 bg-surface-alt rounded-full flex items-center justify-center border border-border">
            <User className="h-8 w-8 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-lg">{profile.name}</h3>
            <p className="text-sm text-secondary">{profile.email}</p>
          </div>
        </div>
        <div className="p-2">
          <button onClick={handleLogout} className="w-full flex items-center justify-between p-4 hover:bg-surface-alt rounded-lg transition-colors text-red-400">
            <span className="flex items-center gap-3 font-medium">
              <LogOut className="h-5 w-5" /> Log Out
            </span>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
        </div>
      </section>

      {/* Appearance & Notifications */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-secondary uppercase tracking-wider ml-1">Preferences</h3>
        <div className="bg-surface border border-border rounded-xl overflow-hidden divide-y divide-border">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              {darkMode ? <Moon className="h-5 w-5 text-purple-400" /> : <Sun className="h-5 w-5 text-yellow-400" />}
              <div>
                <p className="font-medium">Dark Mode</p>
                <p className="text-xs text-secondary">Easy on the eyes</p>
              </div>
            </div>
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                darkMode ? "bg-white" : "bg-surface-alt border border-border"
              )}
            >
              <div className={cn(
                "absolute top-1 h-4 w-4 rounded-full transition-all bg-black",
                darkMode ? "left-7" : "left-1 bg-secondary"
              )} />
            </button>
          </div>

          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5 text-blue-400" />
              <div>
                <p className="font-medium">Push Notifications</p>
                <p className="text-xs text-secondary">Daily reminders</p>
              </div>
            </div>
            <button 
              onClick={handleNotificationToggle}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                notifications ? "bg-white" : "bg-surface-alt border border-border"
              )}
            >
              <div className={cn(
                "absolute top-1 h-4 w-4 rounded-full transition-all bg-black",
                notifications ? "left-7" : "left-1 bg-secondary"
              )} />
            </button>
          </div>
          
          {notifications && (
            <div className="flex items-center justify-between p-4 border-t border-border bg-surface-alt/30">
              <div className="text-sm font-medium">Reminder Time</div>
              <input 
                type="time" 
                value={reminderTime}
                onChange={handleTimeChange}
                className="bg-surface border border-border rounded-lg p-2 text-sm text-white focus:outline-none focus:border-white"
              />
            </div>
          )}
        </div>
      </section>



      {/* Batch Settings */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-secondary uppercase tracking-wider ml-1">Academic</h3>
        <div className="bg-surface border border-border rounded-xl overflow-hidden divide-y divide-border">
          <button 
            onClick={handleChangeBatch}
            className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <GraduationCap className="h-5 w-5 text-purple-400" />
              <div>
                <p className="font-medium">HSC Batch</p>
                <p className="text-xs text-secondary">Current: HSC {batchYear || 'Not Set'}</p>
              </div>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>
        </div>
      </section>

      {/* Data Control */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-secondary uppercase tracking-wider ml-1">Data & Sync</h3>
        <div className="bg-surface border border-border rounded-xl overflow-hidden divide-y divide-border">
          <button 
            onClick={handleImportRoutine}
            disabled={importing}
            className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <FileText className="h-5 w-5 text-emerald-400" />
              <div>
                <p className="font-medium">Import Udvash Routine</p>
                <p className="text-xs text-secondary">Auto-populate planner tasks</p>
              </div>
            </div>
            {importing ? <span className="text-xs animate-pulse">Importing...</span> : <ChevronRight className="h-4 w-4 opacity-50" />}
          </button>

          <button 
            onClick={handleExportData}
            className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <Download className="h-5 w-5 text-blue-400" />
              <div>
                <p className="font-medium">Export Data</p>
                <p className="text-xs text-secondary">Download JSON backup</p>
              </div>
            </div>
            <ChevronRight className="h-4 w-4 opacity-50" />
          </button>

          {clearStep === 0 && (
            <button onClick={handleResetData} className="w-full flex items-center justify-between p-4 hover:bg-red-500/10 transition-colors text-left group">
              <div className="flex items-center gap-3">
                <Trash2 className="h-5 w-5 text-red-400" />
                <div>
                  <p className="font-medium text-red-400">Clear All Cache & Data</p>
                  <p className="text-xs text-red-400/60">Pomodoro, tasks, progress, syllabus — all deleted</p>
                </div>
              </div>
            </button>
          )}
          {clearStep === 1 && (
            <div className="p-4 bg-red-500/10 border-l-4 border-red-500 space-y-3">
              <div className="flex items-center gap-2 text-red-400 font-bold">
                <span>⚠️</span>
                <span>Are you sure you want to delete ALL data?</span>
              </div>
              <p className="text-xs text-red-400/80">This will permanently delete your tasks, Pomodoro sessions, syllabus progress, and all settings. This cannot be undone.</p>
              <div className="flex gap-3">
                <button onClick={handleResetData} className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-sm transition-colors">
                  Yes, Delete Everything
                </button>
                <button onClick={() => setClearStep(0)} className="flex-1 py-2.5 border border-border rounded-xl text-sm hover:bg-surface-alt transition-colors">
                  Cancel
                </button>
              </div>
            </div>
          )}
          {clearStep === 2 && (
            <div className="p-4 bg-red-600/20 border-l-4 border-red-600 space-y-3">
              <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                <span>🚨</span>
                <span>FINAL WARNING: If you click OK, your data is gone forever.</span>
              </div>
              <div className="flex gap-3">
                <button onClick={handleResetData} className="flex-1 py-2.5 bg-red-700 hover:bg-red-600 text-white font-bold rounded-xl text-sm transition-colors">
                  OK, Delete Now
                </button>
                <button onClick={() => setClearStep(0)} className="flex-1 py-2.5 border border-border rounded-xl text-sm hover:bg-surface-alt transition-colors">
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Quick Tools */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-secondary uppercase tracking-wider ml-1">Tools</h3>
        <div className="bg-surface border border-border rounded-xl overflow-hidden divide-y divide-border">
          <Link to="/teachers" className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-lg">👨‍🏫</span>
              <div><p className="font-medium">Teacher Panel</p><p className="text-xs text-secondary">Best YouTube teachers per subject</p></div>
            </div>
          </Link>
          <Link to="/books" className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-lg">📚</span>
              <div><p className="font-medium">Books PDF</p><p className="text-xs text-secondary">All HSC textbook PDFs — mulboi.com</p></div>
            </div>
          </Link>
          <Link to="/whiteboard" className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-lg">✏️</span>
              <div><p className="font-medium">Whiteboard</p><p className="text-xs text-secondary">Draw, write, export PDF</p></div>
            </div>
          </Link>
          <Link to="/calculator" className="w-full flex items-center justify-between p-4 hover:bg-surface-alt transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-lg">🧮</span>
              <div><p className="font-medium">Calculator</p><p className="text-xs text-secondary">Casio fx-991EX scientific calculator</p></div>
            </div>
          </Link>
        </div>
      </section>

      {/* App Info */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-secondary uppercase tracking-wider ml-1">About</h3>
        <div className="bg-surface border border-border rounded-xl overflow-hidden divide-y divide-border">
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Info className="h-5 w-5 text-secondary" />
              <span className="font-medium">Version</span>
            </div>
            <span className="text-sm text-secondary font-mono">v2.0.0 (Production)</span>
          </div>
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-secondary" />
              <span className="font-medium">Security</span>
            </div>
            <span className="text-sm text-emerald-400 flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400" /> Secure
            </span>
          </div>
        </div>
        <p className="text-center text-xs text-secondary pt-4">
          Last updated: March 3, 2026
        </p>
      </section>
    </div>
  );
}
