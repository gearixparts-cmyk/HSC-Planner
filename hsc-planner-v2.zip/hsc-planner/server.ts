import express from "express";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { COMMON_QUESTIONS } from "./src/data/ai-training-data.ts";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Simple in-memory cache for last 5 responses
const aiCache = new Map<string, string>();
const CACHE_LIMIT = 5;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/ai-chat", async (req, res) => {
    const { question, language, mode } = req.body;

    if (!question) {
      return res.status(400).json({ error: "No question provided" });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      console.error("GEMINI_API_KEY is missing");
      return res.json({ answer: "Sorry, AI is temporarily unavailable. Please try again later." });
    }

    // Check cache
    const cacheKey = `${question}-${mode}-${language}`;
    if (aiCache.has(cacheKey)) {
      return res.json({ answer: aiCache.get(cacheKey) });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      
      let modeInstruction = "";
      switch (mode) {
        case 'step-by-step':
          modeInstruction = "MODE: STEP-BY-STEP SOLUTION. Break down the answer into numbered steps. Explain the logic clearly. Use simple language.";
          break;
        case 'summary':
          modeInstruction = "MODE: CHAPTER SUMMARY. Provide a short structured summary, key formulas, important concepts, and common mistakes.";
          break;
        case 'flashcards':
          modeInstruction = "MODE: FLASHCARDS. Generate 5 Q&A pairs in a flashcard format (Q: ... A: ...). Keep answers short and revision-friendly.";
          break;
        case 'quiz':
          modeInstruction = "MODE: MINI QUIZ. Generate 5 MCQs and 2 Short Questions based on the topic. Provide answers at the very end, hidden or separated.";
          break;
        default:
          modeInstruction = "MODE: NORMAL. Answer naturally and helpfully.";
      }

      const commonQA = COMMON_QUESTIONS.map(q => `Q: ${q.q}\nA: ${q.a}`).join("\n");

      const systemPrompt = `
        You are the official AI assistant for "HSC Planner" (formerly HSC26 Planner), a professional web app designed for HSC Science students in Bangladesh.
        
        APP OVERVIEW:
        - Name: HSC Planner
        - Founder: Mohammad Tonmoy (https://www.tonmoy.shop/)
        - Target Audience: HSC Science Students
        - Theme: Minimal, black & white, distraction-free.

        APP FEATURES:
        1. Dashboard: Shows exam countdown (26 June 2026), daily quote, focus card, subject progress, and quick Pomodoro access.
        2. Planner: Daily task manager with checkboxes. Tasks are isolated per date. Includes a daily journal.
        3. Subjects: Resource hub for Math, Physics, Chemistry, Biology, ICT, Bangla, English. Contains playlists (Basic, Oneshot, MCQ) and special notes.
        4. Calendar: Monthly view of tasks and events.
        5. Weekly: Weekly report showing total tasks, Pomodoro sessions, and subject progress.
        6. Pomodoro: Advanced focus timer with Smart Break logic (long break after 4 sessions).
        7. Settings: Import routine (Udvash), export data, reset data, dark mode toggle.
        8. APK Download: Users can download the mobile app via the popup on the homepage.

        COMMON QUESTIONS & ANSWERS:
        ${commonQA}

        YOUR ROLE:
        - Answer user questions about how to use the app using the provided Q&A.
        - Explain study concepts if asked (Physics, Math, etc.) in a simple, storytelling style.
        - Be encouraging and motivating.
        - Support both English and Bengali languages.
        - If the user asks in Bengali, reply in Bengali. If English, reply in English.
        - If asked about the founder, mention Mohammad Tonmoy.
        
        ${modeInstruction}

        User Question: ${question}
        Language Preference: ${language || "detect"}
      `;

      // 10s Timeout
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("AI Timeout")), 10000)
      );

      const aiCall = ai.models.generateContent({
        model: 'gemini-2.5-flash-latest',
        contents: systemPrompt,
      });

      const response = await Promise.race([aiCall, timeoutPromise]);
      const answer = (response as any).text;

      // Update cache
      if (aiCache.size >= CACHE_LIMIT) {
        const firstKey = aiCache.keys().next().value;
        if (firstKey) aiCache.delete(firstKey);
      }
      aiCache.set(cacheKey, answer);

      return res.json({ answer });

    } catch (error) {
      console.error("AI Error:", error);
      return res.json({ answer: "Sorry, AI is temporarily unavailable (Timeout or Error). Please try again later." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
